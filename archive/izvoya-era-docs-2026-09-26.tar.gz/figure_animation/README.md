# Moving figures in Anastasis and Last Judgment

**Current release:** [stronger six-second v2 gestures and previews](v2/README.md).
The earlier assets and recordings below are retained for comparison.

Both scenes now have **Animate figures / Pause figures**, **Still**, and a
**Pose** slider. The current six-second gesture loop animates the painted figures, with a
Movement slider that starts at Bold. The archived v1 recordings below use eight seconds.
Pause freezes their pose; Still restores their original pose. The slider pauses
playback and scrubs the gesture. Zoom, pan and manually selected details remain
available while figures move. The camera never moves automatically with playback.

- **Anastasis:** Christ inclines his head and reaches with both arms; the joined
  hands rise with Adam, Eve bows, robes sway and selected witnesses turn their heads.
- **Last Judgment:** Christ gestures with his hands; Mary and John incline their
  heads and gesture; apostles nod, kneeling figures bow, and the rolling angel's
  wings and garments move.

Original, Relief and Restored views share the same figure motion. All existing
photographs, reliefs and separate restoration files are preserved. Classic v5
remains under Scene options. Playback starts off, pauses on backgrounding or
navigation, and respects reduced-motion preferences; manual pose scrubbing is
still available.

## Preview the motion

- [Anastasis figures — 8-second app recording](previews/anastasis_figures.mp4)
- [Last Judgment figures — 8-second app recording](previews/last_judgment_figures.mp4)
- [Last Judgment angel — 8-second app recording](previews/last_judgment_angel.mp4)
- [Current phone and desktop layouts](previews/layouts/)

## Method

`authoring/*_joints.json` records the local neck, arm, robe and wing joints.
`tool/build_figure_animation.py` uses the existing v5 semantic masks to author
16 gestures for Anastasis and 25 for Last Judgment. It outputs two sparse pose
bases in `assets/explorer/*_figures.json`. `FigureRig` interpolates these with two
smooth cyclic waves on a connected texture mesh. Faces and halos share the same
local head motion. Joined hands share an influence region. Border vertices and
unaffected scenery stay fixed; Last Judgment's loss bands stay fixed as well.

This is an interpretive animation of a single painted view. It uses small local
deformations and a narrow transition beside silhouettes; it does not reveal
newly painted surfaces, synthesize expressions, or reconstruct hidden anatomy.
No textures are generated or overwritten by the animation builder.

`build_report.json` checks 97 poses per scene, including both triangle orientations.
The smallest signed area stays positive (at least 30% of the undeformed triangle),
so the surface does not fold or tear. Runtime grids have 35,209 / 44,204 vertices;
only 5,675 / 3,414 are animated. UVs, topology and motion data are cached.

## Rebuild and inspect

```sh
python3.11 tool/build_figure_animation.py
flutter test --no-pub
flutter analyze --no-pub
flutter test --no-pub tool/interactive_scene_screenshot_test.dart
flutter test --no-pub tool/figure_animation_capture_test.dart
flutter build web --no-pub
flutter build apk --release --no-pub
```

Widget checks cover visible movement, a fixed camera, byte-identical paused
frames, Still returning to the original rendered frame, scrubbing, all three
image variants, zoom during playback, reduced motion, lifecycle and disposal.
The numerical check samples the full loop to verify fixed scenery and positive
triangle areas. Layout captures cover 360×800, 390×844, 430×932 and 1440×900.

Capture frames are written to `/tmp/chora-figure-frames`; the preview movies use
actual Flutter renders of an entire eight-second loop. These are software-rendered
widget captures; physical-device frame rate has not been measured.

## Verified result

32 application tests and both visual capture tests passed. The final marker
visibility adjustment also passed both scene playback tests. Flutter analysis
reports no issues. Web and Android release builds succeed; both bundles were
checked against the workspace originals, restoration images and figure rigs.
All 386 existing scene assets remain byte-for-byte unchanged. See
[validation_report.json](validation_report.json) and
[original_preservation_report.json](original_preservation_report.json).

## Web image lifetime regression

The installed CanvasKit engine disposes the image passed to an ImageShader when
that shader is explicitly disposed. Releasing a per-frame shader therefore
invalidated the scene texture, causing `native_memory.dart:113` assertions on
subsequent frames. The browser regression test reproduced this on frame zero.

The rig now caches one shader per image for the screen's lifetime. Native
platforms dispose those shaders when the screen closes. On web, the bounded
cache is released to the engine's native finalizers, avoiding CanvasKit's
borrowed-image disposal. ExplorerAssets remains the owner that disposes scene
images. Per-frame vertex resources are still explicitly released.

`flutter test --platform chrome test/figure_renderer_lifetime_test.dart` now
passes, exercising 24 successive blended poses and texture ownership at cleanup.
The 33-test native suite and analysis also pass. The actual debug app was checked
in Chrome with Original/Relief/Restored playback, zoom, pause, Still and navigation
for both scenes, with no browser errors or warnings. The existing asset-heavy
widget suite timed out loading assets under the web test harness, so the actual
browser app was used for scene-level verification.

# Stronger figure gestures

The six-second loop starts at **Bold** movement strength. Maximum travel is
51 source pixels for Anastasis (3.11× v1) and 33 for Last Judgment (2.97× v1). Use **Movement** to
reduce it toward Gentle, **Pose** to scrub, **Pause figures** to freeze a gesture,
and **Still** to restore the original pose. Zoom and pan remain available during
playback. Camera movement is controlled separately by the user.

Anastasis gives the joined hands a larger lift, raises Adam, bows Eve and turns
heads. Last Judgment opens Christ's hands, moves the Deesis figures and apostles,
and gives the angel a larger wing gesture. The same poses work with Original,
Relief and the full-strength 4K Restored view.

Faces and hands use rigid control regions; an as-rigid-as-possible mesh solver
lets nearby robes and silhouette transitions absorb the bends. This is an
interpretive deformation of the painting's surface, with fixed distant scenery
and borders. It does not reconstruct hidden anatomy. Strong poses inevitably
change nearby outlines, and Gentle is available for less exaggeration.

## Assets and verification

`tool/build_figure_animation_v2.py` creates 48 cyclic poses per scene and writes
separate `assets/explorer/*_figures_v2.json` metadata and `*_poses_v2.bin` float32
data. The original v1 builder, rigs and recordings are preserved. The runtime
interpolates poses and scales their strength without touching image files.

[build_report.json](build_report.json) records maximum travel, comparison with v1,
mesh size, and positive triangle-area checks across 192 interpolated poses at
four movement strengths. [authoring](authoring/) contains the rigid joint handles.

The shader lifetime fix for CanvasKit is retained: shaders are cached per scene
image, and the scene asset owner controls texture disposal. Fully restored frames
skip drawing the hidden original layer. Native and browser regression tests cover
repeated rendering and texture ownership; scene tests check playback, pause,
Still, zoom, strength, 4K dimensions and preserved earlier studies.

## Reproduce

```sh
OPENBLAS_NUM_THREADS=1 python3.11 tool/build_figure_animation_v2.py
flutter test --no-pub
flutter analyze --no-pub
flutter test --no-pub --platform chrome test/figure_renderer_lifetime_test.dart
flutter test --no-pub tool/interactive_scene_screenshot_test.dart
flutter test --no-pub tool/figure_animation_capture_test.dart
flutter build web --no-pub
flutter build apk --release --no-pub
```

The capture script writes actual Flutter frames to `/tmp/chora-figure-v2-frames`.
Pass `--dart-define=PREVIEW_ONLY=true` for five review poses instead of a full loop.
Physical-device frame rate has not been measured.

## Current previews

- [Anastasis](previews/anastasis_figures.mp4)
- [Last Judgment — Deesis](previews/last_judgment_figures.mp4)
- [Last Judgment — angel](previews/last_judgment_angel.mp4)
- [Phone and desktop layouts](previews/layouts/)
- [4K restoration files and provenance](../../restoration_studies/v2/README.md)

## Verified release

35 application tests, two visual capture tests, and both Chrome renderer regression
tests pass. Analysis reports no issues. Web and Android release builds pass;
their scene/restoration/rig assets match the workspace byte for byte. Live Chrome
checks cover restored playback, zoom, pause, Still, scrubbing, intensity and
scene exit without console errors or warnings. See [validation_report.json](validation_report.json).

# Last Judgment — Anastasis v5 method

Scene **F05** is available in the **Judgment** tab, the Scenes catalog and scan
results. The viewer starts with the relief, has Original/Relief comparison and
Overview, Whole vault, Deesis, Christ, Heavens and Throne focus windows.
The camera and illumination stay fixed, matching Anastasis v5. Long-press the
viewer title for the semantic map, height, normals, raking light and 45° surface.
The tab also includes three close reference photographs and the complete vault.

## Surface and source

The master is the complete 1600×1067 `web-ke-02-Mahser.jpg` photograph in the
user-supplied F05 capture folder. It preserves both registers, the upper vault,
original colors, visible losses and the photographer's credit. The screenshot
sequence and other views were reviewed for context; they are not stitched or
projected into the master. See `assets/last_judgment/sources.json` for the full
44-image inventory, selected source filenames, dimensions and SHA-256 hashes.
Photographs: **Caner Cangül**.

The surface uses the existing Anastasis v5 shading and side-view renderer:

- One connected height field: every original pixel occurs once, with no
  transparent cutouts, duplicate figures or exposed backing photograph.
- 77 authored parts, including separate apostle bodies and halos, rear court
  halos, middle court figures, Mary and John, Christ and mandorla, rolling angel,
  heavenly groups, throne, kneeling figures, seats and river of fire.
- 25 reviewed SAM masks, explicit ellipse/polygon corrections and painted
  overlap order, stored in `authoring/`. Normal builds require no SAM model.
- Rounded edges, shallow body volume and head domes. Heights scale with master
  width to match the relief proportions of the 2048 px Anastasis master.
- Existing loss bands remain shallow areas of the same surface. Nothing is
  painted into missing portions of figures.
- The same upper-left light and **0.88–1.08** light multiplier as Anastasis v5,
  plus soft contact shadows and ambient occlusion. No pigment-derived noise,
  recoloring, animation, gyroscope or automatic camera motion.

## Review artifacts

- [Original / relief / raking comparison](comparison.jpg)
- [Semantic overlay](semantic_overlay.jpg)
- [16-bit height field](height16.png): stored value / 256 = depth in master pixels
- [Connected vertex-colored mesh](relief_mesh.ply): 4 px sampling; full-resolution
  height map remains the authoritative surface
- [Production relief](../../../assets/last_judgment/relief_v5/relief_front.jpg)
- [45° inspection](../../../assets/last_judgment/relief_v5/side45.jpg): depth ×1.5
- [Flutter captures](flutter/): 360×800, 390×844, 430×932 and 1440×900; detail
  crops and original pairs at 390×844
- [Build metrics](build_report.json)

The production assets above live at `assets/last_judgment/relief_v5/` in the
repository root. Only the display images and manifest ship in the app; the mesh,
full height field and authoring masks remain development artifacts.

## Reproduce and verify

```sh
# Optional; normal builds use the bundled source copies.
python3.11 tool/prepare_last_judgment_assets.py /path/to/F05-folder
python3.11 tool/build_last_judgment_v5.py
flutter test --no-pub
flutter test --no-pub tool/mobile_last_judgment_screenshot_test.dart
flutter analyze --no-pub
flutter build web --no-pub
```

Dependencies match Anastasis v5: Python 3.11, NumPy, OpenCV, SciPy and Pillow.
To revise segmentation, set `SAM_CHECKPOINT` and run
`tool/last_judgment_sam_masks.py [part ids]`; then rebuild. The checked-in masks
are the reproducible source of truth, not a dependency on a temporary checkpoint.

## Validation

All 23 app tests pass, including the existing Anastasis tests. The additional
Flutter capture test passes at three phone sizes and desktop, and checks that
a drag does not change a pixel. Static analysis reports no issues. Web and
Android debug and release builds succeed.

## Limits

This is authored pictorial relief, not a measured reconstruction of the vault.
Some overlapping robes and damaged upper groups are approximate; the upper
crowds are grouped rather than individually modeled. Lighting is baked, as in
Anastasis v5. The complete vault master has less detail than the close-up
references, which are available separately in the app. Phone captures are
Flutter widget renders, not measurements on a physical device.

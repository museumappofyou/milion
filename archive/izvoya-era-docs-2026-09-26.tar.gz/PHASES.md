# İzvoya — Android development phases

Updated: 2026-09-26. Product: **İzvoya**; code/package: `izvoya`; Android ID: `com.izvoya.istanbul`; workspace: `/Users/memre/Desktop/izvoya`.

## How to run this plan

Copy one numbered code block into a new task. Read this file and `PROGRESS.md` first; execute its dependencies before its dependent work. P00 is the audit/rebrand performed in this run; P01–P35 are implementation work, not completed features. Every phase must produce something demonstrable and record evidence and a percentage change, including zero when blocked. Finishing a prompt does not itself earn 100%.

These are the only two active planning documents: this file owns scope, execution prompts, decisions and external open issues; `PROGRESS.md` owns the audit, scores, validation evidence, phase status and concise change history. Do not create further Markdown plans, reports or checklists. Existing historical READMEs are legacy evidence, not current instructions; retain them without duplicating their contents here. Code, datasets, images, JSON reports and test artifacts may live in their appropriate directories.

## Product contract

**Promise:** Istanbul, layer by layer. Reveal a detail people would otherwise miss, explain why it matters, then help them find its place in the city. A visitor should experience the first compelling reveal within 30 seconds, without an account, camera access, payment or location permission.

**Audience order:** curious Istanbul residents returning on weekends; independent first-time visitors with limited time; art/architecture enthusiasts exploring remotely. Include families and people with mobility, vision or hearing needs in research. Turkish and English are the launch languages. Android is the only release platform; existing web code may support previews, but there is no web or iOS delivery phase.

**Content order:** Byzantine/Eastern Roman places and art first; mosques and their architectural/craft traditions second; museums and objects third. A place can belong to several eras and categories without duplicate records. Present current names and functions alongside historical names; contested identifications remain attributed hypotheses. Mosque stories emphasize light, space, ornament and craftsmanship; avoid arbitrary animated worship or invented historical events.

**Attraction loop:** encounter a striking scene → make a small discovery → save it to a personal cabinet → connect it to a nearby place or short route → share a selected moment → return for another authored chapter. Pleasure, understanding and personal meaning must be demonstrated; more animation, longer sessions or more notifications are not success by themselves.

**Visual direction:** an Istanbul field atlas with the intimacy of a collector's cabinet. Build from measured stone inscriptions, actual mosaic edges, architectural plans, waterside contours and documentary images. The İzvoya mark uses four offset tesserae, a water-shaped gap and one terracotta trace. Use the existing offline serif/sans fonts initially, with generous artwork space, strong captions and carefully drawn maps. Avoid repeated rounded-card grids, ornamental gradients, generic temple icons, stock skyline collages, fake aged textures, slogan-heavy hero pages and decorative movement. Put a specific discovery before a marketing paragraph. Establish a small set of distinct compositions: chapter opening, map, object plate, architectural cutaway, route strip and personal cabinet.

**Motion hierarchy:** brief transitions explain navigation; 2.5D reveals pictorial depth; real 3D explains spatial relationships. Original, depth interpretation and reconstructed interpretation must remain understandable and directly comparable. Keep static originals untouched, one-tap reset, reduced-motion alternatives and user-controlled playback. Never sell a surface warp or an upscaled restoration as a measured reconstruction. The current animated figures are useful prototypes, not proof that exaggerated movement is desirable.

**Engineering guardrails:** stable globally scoped IDs; migration of existing F02/F05 links and scene notes; feature-independent content; small offline starter; downloadable versioned packs; deterministic builds; honest unknown/error/closed states; no mandatory account. Avoid a citywide recognition claim until separately evaluated. Preserve existing source credits and originals; rights clearance is deferred during private prototyping as requested, not a development workstream. The owner handles public asset choices when publication is actually considered.

## Bounded release scope and budgets

“All Istanbul” means citywide discovery and an expandable registry, not a claim to catalogue every building. These proposed minimums define the denominator; revise them explicitly with rationale before implementation if evidence justifies a change, never silently shrink them to improve scores.

| Deliverable | Acceptance baseline |
| --- | --- |
| Geographic coverage | Research all 39 districts; publish at least one meaningful, verified place/story per district, with travel/access uncertainty explicit. |
| Curated catalogue | At least 90 distinct, reviewed places, including at least 24 Byzantine-related, 24 mosque and 24 museum entries; overlap categories does not increase the distinct-place count. Preserve all 103 existing Chora scene records. |
| Collectible visual experiences | At least 12 approved 2.5D pieces (6 Byzantine, 3 mosque/craft, 3 museum/object) and 6 genuine 3D exhibits (2 per wave), each with an original/reference, a meaningful interaction, interpretation label, fallback and measured device cost. |
| Narratives and routes | At least 18 authored visual stories; 12 reviewed routes across both shores (4 Byzantine, 4 mosque, 4 museum/mixed), including short, rain-friendly and lower-exertion choices; no unverified accessibility claims. |
| Language and accessibility | Turkish/English UI and release content; TalkBack primary flows, 200% text scaling, 48 dp targets, tested contrast, motion-off and caption/transcript equivalents. |
| Entry and offline use | First reveal ≤30 s in usability sessions; starter catalogue, notes and one flagship work after first install in airplane mode; no forced login. |
| Android performance | Proposed supported floor: Android 10/API 29 and a physical 4 GB RAM phone; validate before freezing support. Cold start to useful home p95 ≤3 s over 30 release runs; downloaded experience opens p95 ≤2 s. UI/2.5D p95 frame time ≤16.7 ms at 60 Hz; low-tier true 3D ≤33.3 ms with explicit quality mode. No sustained thermal collapse over 15 min. |
| Resource budgets | Initial device-specific download ≤80 MB, starter media ≤25 MB, ordinary optional pack ≤40 MB (larger packs show size explicitly), default 3D ≤150k visible triangles/50 draws/2K textures. These are provisional engineering budgets, not measured current results. Peak PSS target ≤350 MB on the floor phone; no monotonic memory growth over 20 open/close cycles. |
| Recognition | Chora suggestions only until held-out evaluation: ≥90% top-3 recall and ≤2% false acceptance on at least 500 real positive and 250 non-catalogue images, split by capture session/source. At least 90% of supported scenes represented; report per-scene omissions. City extensions require their own dataset and gates. |
| Human evidence | At least 30 participants: 10 residents, 10 visitors, 10 remote enthusiasts. ≥80% complete reveal/save/find-place without assistance; ≥70% correctly distinguish original from interpretation; ≥60% report a concrete reason to return. Pilot 20 opted-in testers for 14 days, ≥500 sessions, ≥99.5% crash-free sessions, no unresolved reproducible ANR or critical defect. |

The size/performance/research numbers are project acceptance targets, not claims about Android platform requirements or statistical certainty. Store-policy requirements must be checked when releasing. Successful technical performance alone does not prove product attraction.

## City coverage register

This is a research queue, not verified visitor guidance. Check current official operators, coordinates, entrances and access before publishing. The 39-district boundary comes from [İBB's jurisdiction description](https://ibb.istanbul/ibb/belediye-hakkinda/yetki-alani/). Each district needs separate coverage counters in the eventual catalogue.

| Research cluster | Districts | Editorial opportunity |
| --- | --- | --- |
| Historic core and central institutions | Fatih, Beyoğlu, Beşiktaş, Şişli | Byzantine layers, imperial mosques, collections, architecture and modern art. |
| Bosphorus | Sarıyer, Beykoz, Üsküdar | Cross-shore connections, waterfront mosques, fortifications and museums. |
| Inner Anatolian side | Kadıköy, Ataşehir, Ümraniye, Çekmeköy | Local history, contemporary cultural places and neighborhood discovery. |
| Marmara and islands | Adalar, Maltepe, Kartal, Pendik, Tuzla | Island museums, maritime connections and archaeological stories. |
| Eastern and northern hinterland | Şile, Sancaktepe, Sultanbeyli | District heritage and small institutions; research rather than fabricate Byzantine coverage. |
| Golden Horn and northern neighborhoods | Eyüpsultan, Kağıthane, Gaziosmanpaşa, Sultangazi | Water systems, worship, industry and local memory. |
| Walls and western inner districts | Zeytinburnu, Bakırköy, Bayrampaşa, Esenler, Güngören | Walls, changing settlements, museum/craft connections. |
| Western metropolitan belt | Bahçelievler, Bağcılar, Başakşehir, Küçükçekmece | Archaeological candidates, district museums and civic heritage. |
| Western coast | Avcılar, Beylikdüzü, Esenyurt, Büyükçekmece | Bridges, waterfront routes, local collections and newer city layers. |
| Western/northern edge | Arnavutköy, Çatalca, Silivri | Long walls, landscape history, settlement museums and day-trip distances. |

**Byzantine candidates:** Kariye/Chora, Ayasofya, Aya İrini, Great Palace Mosaics, Yerebatan, Şerefiye, Binbirdirek, Zeyrek/Pantokrator, Fethiye/Pammakaristos, Fenari İsa/Lips, Bodrum/Myrelaion, Küçük Ayasofya, Eski İmaret, Gül, Vefa Kilise, Studios/İmrahor, land walls and gates, Blachernae, Tekfur, Valens aqueduct, Hippodrome, Constantine's column, Boukoleon and Mangana remains. Wider candidates: Küçükyalı Arkeopark, Bathonea, the Anastasian Wall and Yoros. Verify scholarly identifications and reachable viewpoints; ruins may be closed or inaccessible. [UNESCO's site description](https://whc.unesco.org/en/list/356/) supports the layered historic core, not the current visitor status of every candidate.

**Mosque candidates:** Süleymaniye, Sultanahmet, Şehzade, Rüstem Paşa, Sokollu Mehmet Paşa, Yeni Cami, Nuruosmaniye, Fatih, Eyüp Sultan, Laleli, Beyazıt, Mihrimah Sultan in Edirnekapı and Üsküdar as separate places, Kılıç Ali Paşa, Nusretiye, Ortaköy/Büyük Mecidiye, Dolmabahçe/Bezmialem Valide Sultan, Atik Valide, Çinili, Şemsi Ahmed Paşa, Şakirin, Büyük Çamlıca, Sancaklar and Pertevniyal Valide Sultan. Reuse the Byzantine-converted buildings' shared place records. Routes must account for worship and separate verified visitor access from prayer access.

**Museum candidates:** Istanbul Archaeological Museums, Turkish and Islamic Arts, Topkapı, Great Palace Mosaics, Rahmi M. Koç, Deniz/Maritime, Pera, Istanbul Modern, Sakıp Sabancı, Sadberk Hanım, İstanbul Resim ve Heykel, Arter, Museum of Innocence, Tekfur, Panorama 1453, Miniatürk, Gazhane, Barış Manço, Adalar Museum, Sait Faik, Aşiyan, Hisart, Ural Ataman and district/local-history collections. Confirm whether each candidate is a museum, cultural venue or monument; do not label them all as the same institution type. Museum objects need separate inventory IDs and display-location freshness.

## 2.5D / 3D editorial production matrix

| Subject | Best starting format | Reason to interact | Reject when |
| --- | --- | --- | --- |
| Fresco/mosaic scene | Authored relief + restrained semantic figure motion | Follow a hand, discover overlap, compare surviving paint. | Faces stretch, edges tear, nearby figures double, or motion tells an unsupported story. |
| Mosaic/tile/calligraphy craft | Macro 2.5D with grazing light or ordered assembly | Understand material, stroke or repeating geometry. | Random floating fragments, altered inscription or arbitrary shimmer. |
| Cistern / dome / church / mosque | True 3D cutaway, orbit limits and lighting study | Understand volume, supports and successive building layers. | A single photo plane is sold as a full reconstruction or unseen surfaces are presented as measured. |
| Museum object | True 3D turntable with meaningful annotated views | See an inaccessible side, construction or working mechanism. | Rotation adds no information, scale is missing or geometry invents undocumented details. |
| City over time | Georeferenced 2.5D map layers; selected 3D landmarks | Locate vanished structures and compare documented time slices. | Fake historical certainty or drifting alignment makes the comparison misleading. |
| Social excerpt | User-selected 6–10 s reveal or still diptych | Communicate one discovery and link to its source experience. | It is a long UI recording, unsolicited upload or an unlabeled restoration. |

Suggested pilots: the two current Chora pieces; an Ayasofya mosaic detail; a palace mosaic; a wall/gate section; a cistern spatial study; Rüstem Paşa tile craft; a Süleymaniye dome cutaway; a Şemsi Paşa waterfront spatial study; a sarcophagus/object turntable; a maritime mechanism; a painting/material detail. These are commissioning ideas, not available/approved assets. Select the final 18 visual experiences through P06/P07/P30 quality and audience evidence.

Use glTF as a candidate 3D delivery format and evaluate compressed textures against the chosen Android renderer; [Khronos glTF](https://www.khronos.org/gltf/) and [KTX](https://www.khronos.org/ktx/) describe the formats. Renderer support, Flutter integration, frame pacing and asset suitability still require P07 measurements. Do not assume every extension is supported.

## Phase prompts

### P00 — Audit, identity and path migration

```text
Execute P00: Audit, identity and path migration for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: None; this run establishes the baseline.

Audit source, tests, Android configuration and current screenshots/animation frames before editing. Apply the İzvoya identity, code package izvoya, Android ID com.izvoya.istanbul, theme/IDE/Kotlin paths, custom tessera-and-water mark, launcher densities, adaptive/themed icons and splash. Keep Chora as the real place/recognition-model name. Align existing preview metadata; do not build iOS. Rename the workspace to /Users/memre/Desktop/izvoya without overwriting another directory, then regenerate path-dependent Flutter metadata. Explain that the changed Android application ID installs separately and cannot silently read the old sandbox's notes.
Acceptance: existing app tests and analyzer pass, Android APK builds with the new identity, narrow/large-text headers render, source artwork hashes stay unchanged, and all requested planning is in exactly these two active Markdown files. Record device-only launcher checks as unverified. Rerunning this prompt must audit completed changes, not repeat them or overwrite later progress.
Demo: new home wordmark, launcher artwork and installable APK. Dimensions: D01–D04, D36, D43.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P01 — Scalable local domain and repository foundation

```text
Execute P01: Scalable local domain and repository foundation for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P00.

Separate places, buildings, artworks, stories, media variants, routes, packs and user records into typed models/repositories. Add district, coordinates, era intervals, current function, historical aliases, languages, review timestamps and source references. Give places stable global IDs; scope current scene IDs to Chora while retaining F02/F05 compatibility. Decouple browsing from classifier class order and static ExplorableScene constants. Establish schema versions and migrations with real fixtures. Preserve notes and favorites across an in-app schema upgrade; design explicit export/import for the old Android package because its sandbox is separate. Set up local version control after inspecting existing work; do not publish remotely.
Acceptance: existing 103 Chora records load independently of ONNX; a second-place fixture loads through the same model; invalid/duplicate IDs fail validation; a legacy note survives migration/import with no duplication. Keep placeholder fixtures out of the public catalogue.
Demo: two places through one repository and a recovered legacy note. Dimensions: D06, D19, D34, D37.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P02 — Art direction and distinctive interaction grammar

```text
Execute P02: Art direction and distinctive interaction grammar for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P00.

Turn the product contract into implemented Flutter visual primitives and six reviewable compositions: chapter opening, map/list, artwork plate, cutaway, route strip and cabinet. Create at least two genuinely different phone compositions before choosing the strongest; assess information hierarchy, artwork area, one-handed reach and recognizability with the name hidden. Use the İzvoya mark consistently, source-derived geometry and Turkish glyphs. Define typography, color/contrast, spacing, icon stroke, caption rules, transition timing, focus and loading/error states in code. Replace generic decorative icons where the historical meaning is wrong. Do not merely swap the palette or add rounded cards.
Acceptance: actual 360/390/430 dp screens at 100% and 200% text, one dark artwork view, no clipped controls, and one clear primary action per composition. Record the selected direction/rationale and unresolved owner taste input here; implementation does not wait for optional preference feedback.
Demo: side-by-side working compositions. Dimensions: D02, D03, D30, D31.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P03 — Android shell and first discovery

```text
Execute P03: Android shell and first discovery for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P01, P02.

Implement a compact Android shell centered on Discover, Atlas and Cabinet; expose Scan as an intentional action and put About/settings behind utility navigation. Start with one specific visual discovery, its real place and duration, not a long sales introduction. Offer visitor/local/remote context as optional choices; first reveal works offline and without permission requests. Preserve back behavior, scroll, selected filters and in-progress scene state. Add useful loading, empty, unavailable and retry states, including catalogue load failure. Make system bars and edge-to-edge insets behave correctly.
Acceptance: home → reveal → save → place → back works one-handed; no ONNX/camera startup while browsing; first-time and returning sessions differ meaningfully; initial path is testable in ≤30 seconds. Keep new city content visibly unavailable until it exists rather than filling the UI with dummy entries.
Demo: a complete first-minute journey and returning-user resume. Dimensions: D04, D05, D31, D32.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P04 — Editorial schema, provenance and city research registry

```text
Execute P04: Editorial schema, provenance and city research registry for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P01.

Create a validated, machine-readable 39-district research registry and structured editorial content pipeline. Separate verified facts, attributed interpretations, unknowns, physical access and current visitor information. Every release record needs official/local scholarly sources, reviewer/date, coordinates/entrance, language status, media provenance, category and next-review date. Store opening hours as dated claims with exceptions/time zone, never an eternal string. Model “unknown”, “closed”, “exterior only” and “unverified” without inventing certainty. Keep one place record across Byzantine and mosque views. Establish publication gates and exact category/district counters against this file's baseline. Seed candidate names from this file; verify before promoting them.
Acceptance: validators catch missing sources, stale visit data, duplicate alias records and unsupported reconstructions. One thoroughly reviewed Chora place record and the 39-district queue render through the app; unpublished candidates remain hidden.
Demo: published versus pending records with visible sources. Dimensions: D06–D12, D38.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P05 — Artwork viewer with a clear primary experience

```text
Execute P05: Artwork viewer with a clear primary experience for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P02, P03.

Refactor the existing shared viewer into an artwork-first experience. Default to a clean framed scene and one authored reveal; keep pan/zoom, detail discovery, original comparison and one-tap reset immediately understandable. Move pose, strength, diagnostics and alternate studies into a secondary sheet; retain their capabilities and regression coverage. Make Original show the unmodified source pose, with interpretive animation clearly distinct; direct original/interpretation comparison stays aligned. Preserve reduced-motion manual discovery, lifecycle pause, captions and accessible controls. Keep controls off significant faces/inscriptions and account for narrow screens and landscape.
Acceptance: both current scenes work with source/relief/restored states, no accidental playback on resume, no hidden “still” state, no lost zoom on comparison, and no asset lifetime regressions. Compare before/after artwork viewport area and interaction steps.
Demo: the same detail discovered in each scene in under three actions. Dimensions: D03, D16, D17, D23, D30.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P06 — Repeatable 2.5D and authored motion production

```text
Execute P06: Repeatable 2.5D and authored motion production for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P04, P05.

Build a manifest-driven authoring/export/QA pipeline from the current relief and figure-rig scripts. Version originals, masks, depth, joints, poses, restoration variants, localized hotspots, thumbnail, static fallback and performance estimate. Remove machine-specific paths; make builds reproducible from approved inputs. Introduce restrained movement profiles and a short authored reveal per scene; examine full-loop recordings at phone size and close-up. Check rigid faces/hands, limb joins, inscriptions, disocclusion, edge stretching, triangle orientation and restored alignment. Preserve source hashes and label uncertain reconstruction. Compare the two current pieces before commissioning more.
Acceptance: rebuild both current scenes from manifests, approve their whole-loop visual QA, and produce one additional Byzantine piece with the same pipeline and no custom screen. Automated positive triangle area is necessary but does not substitute for visual review. Record bytes/time per piece and failed review reasons.
Demo: three pieces with static, moving and original comparison. Dimensions: D16, D17, D19, D23.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P07 — True 3D Android renderer and first spatial exhibit

```text
Execute P07: True 3D Android renderer and first spatial exhibit for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P01, P02, P04.

Evaluate a small native Android renderer integration (for example Filament) against a maintained Flutter-compatible route using the same real glTF sample. Check actual maintenance, licensing/dependencies and supported features from primary documentation at execution time. Prototype a sourced cistern bay or architectural section, not the whole city. Measure startup, interaction, textures, gesture conflicts, TalkBack alternatives, offline loading, pause/dispose and context loss on physical Android if available. Choose the smallest maintainable solution based on evidence; do not claim a WebView/native bridge is free of cost. Support orbit limits, cutaway or assembly explanation, scale, reset, hotspots and still fallback. Validate compression support before enabling it.
Acceptance: a genuinely spatial exhibit with coherent side/back surfaces and labeled hypotheses; repeatable device frame/memory results meeting the budgets or a documented unresolved gate. If hardware/source access is missing, finish the prototype but do not mark renderer validation complete.
Demo: rotate/cut away to learn something a single image cannot show. Dimensions: D18–D20, D32.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P08 — Downloadable packs and resilient offline use

```text
Execute P08: Downloadable packs and resilient offline use for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P01, P06, P07.

Design a tiny installed starter and versioned optional place/experience packs. Decouple diagnostics, old relief generations and high-resolution studies from release assets without deleting authoring evidence. Show download size, available storage, progress, cancel/retry, Wi-Fi preference and removal. Verify checksums and schemas; activate packs atomically and keep a known-good version if interrupted/corrupt. Separate user notes from removable media and protect pinned packs from automatic eviction. Prepare a local/fake-server transport and production endpoint configuration; never invent credentials or quietly purchase hosting. Cache thumbnails and offer still/low-quality alternatives.
Acceptance: airplane-mode first discovery works; interrupted download/restart, low storage, invalid hash, older app/newer manifest and pack removal are tested; deleting a pack preserves notes/saves. Report measured starter and per-pack bytes.
Demo: download, use offline, interrupt, recover and remove one pack. Dimensions: D19–D21, D34, D35.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P09 — Chora as the flagship collectible chapter

```text
Execute P09: Chora as the flagship collectible chapter for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P04–P08.

Turn the existing 103-scene catalogue into an authored Chora chapter: building/room orientation, named details, short sequences, quiet original viewing and source/reference access. Review all current summaries and historical labels; eliminate catalogue-folder jargon from visitor UI. Produce at least four approved 2.5D works including the two existing scenes and one spatial building/room exhibit. Define a 5-minute remote visit and an on-site sequence that remains useful when a room/artwork is inaccessible. Curate comparison/restoration as explicit interpretation, not the default appearance of the monument. Give every piece one memorable question and one factual answer.
Acceptance: all 103 legacy scenes/notes remain reachable, at least four visual pieces pass P06 QA, first spatial work passes P07, and the chapter functions entirely from its downloaded pack. Do not claim indoor positioning without evidence.
Demo: a five-minute Chora visit and a collected detail. Dimensions: D09, D12, D16–D18, D23.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P10 — Byzantine imperial core beyond Chora

```text
Execute P10: Byzantine imperial core beyond Chora for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P09.

Create the next Byzantine chapter around Ayasofya, Aya İrini, palace mosaics, the Hippodrome and the major cisterns. Verify current operators/functions/visitor access from primary sources; distinguish monuments, museum institutions and artworks. Add reviewed architecture, material and human stories with historical aliases and chronology. Reach at least 12 distinct Byzantine-related place entries, six approved Byzantine 2.5D pieces and two true 3D exhibits in total. Prioritize one mosaic close-reading and one spatial reveal; select subjects based on adequate source material rather than famous names alone. Avoid reusing one interaction for every place.
Acceptance: each promoted place meets the editorial schema, each experience has its own discovery and still fallback, all published content is sourced, and current Chora data is not duplicated as a new institution.
Demo: move from a painted scene to a built space across three different places. Dimensions: D09, D12, D16–D18, D23.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P11 — Byzantine neighborhoods, ruins and outer connections

```text
Execute P11: Byzantine neighborhoods, ruins and outer connections for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P10.

Extend the Byzantine layer to at least 24 verified places: converted churches, walls/gates, aqueducts, palace remnants and suitable outer-city sites from the candidate queue. Prioritize Zeyrek/Fener-Balat, the land walls and a documented Anatolian/western connection. Represent successive uses, disputed identifications and surviving versus reconstructed features. Plan meaningful exterior-only stories for closed sites; never route through private/restricted land. Publish multiple levels of certainty for time-layer overlays and clear distances for remote sites. Verify coordinate/entrance precision and distinguish nearby but different structures.
Acceptance: 24 distinct entries pass review, their historical aliases find the right record, at least three neighborhood sequences are coherent, and the app shows uncertainty/closed status without a dead end. Put missing field/source work into external issues, not fabricated content.
Demo: a famous-to-overlooked chain of three discoveries. Dimensions: D07–D09, D12, D23.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P12 — Atlas, search and geographic discovery

```text
Execute P12: Atlas, search and geographic discovery for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P03, P04, P11.

Build the Atlas with a visually specific, legible map and equivalent list. Index Turkish diacritics, historical aliases, category, district, era, available experience, saved state and access status. Add sensible clustering and selected-place/list synchronization. Default to a manual district or Istanbul view; request foreground location only for a user-triggered nearby action. Show approximate distance and source freshness; do not infer opening status from stale data. Compare map provider/offline costs and support; keep a local map/list fallback until credentials are supplied. Avoid a generic wall of pins and do not render all 3D assets on the map.
Acceptance: search “Kariye/Chora”, “Ayasofya/Hagia Sophia”, dotted/dotless I and empty results correctly; location-denied/offline flows stay useful; filters/back state survive. Record provider choice and cost assumptions here.
Demo: find an unfamiliar nearby story with and without location. Dimensions: D08, D13, D15, D21, D33.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P13 — Short routes and practical visit planning

```text
Execute P13: Short routes and practical visit planning for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P11, P12.

Implement ordered routes with duration ranges, walking distance, slope/stairs evidence, rest options, entrance pins, transport/ferry handoff, downloaded status and closed-stop alternatives. Start with four Byzantine routes: compact historic core, Chora/walls, a neighborhood conversion story and a cross-city/outer-site option. Model travel and visit time separately; crossing the Bosphorus is not a straight-line walk. Let users remove/reorder stops, resume, save and export an itinerary. Label an unwalked route as unverified; publish a fully usable route only after field checks. Keep external navigation handoff explicit.
Acceptance: route totals update, closure/permission/offline states work, there is a shorter alternative, and one route can be completed without continual camera use. Do not promise wheelchair access from map geometry alone.
Demo: build a 60–90-minute plan, download it and replace a closed stop. Dimensions: D12–D14, D21, D34, D41.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P14 — Mosque architecture and craft flagship chapter

```text
Execute P14: Mosque architecture and craft flagship chapter for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P11, P13.

Begin the mosque wave with Süleymaniye, Sultanahmet, Şehzade, Rüstem Paşa and contrasting smaller examples. Build 12 reviewed entries and at least two mosque/craft 2.5D pieces plus one genuine 3D architectural exhibit. Make the attraction spatial: a dome's support sequence, shifting daylight, tile repetition, a courtyard threshold or a calligrapher's material process. Source all reconstructions and preserve inscriptions. Add practical visitor etiquette, photography/access distinctions, worship-time interruptions and quiet captions without assuming fixed access rules. Reuse shared building records for converted Byzantine sites.
Acceptance: neither the UI nor the content treats an active mosque as a generic museum; stories remain useful silently and remotely; sacred figures/prayer are not animated as spectacle. Verify visit guidance dates and mark unknowns.
Demo: a craft reveal followed by a readable spatial cutaway. Dimensions: D10, D12, D16–D18, D23.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P15 — Mosques across both shores and architectural periods

```text
Execute P15: Mosques across both shores and architectural periods for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P14.

Expand to 24 distinct reviewed mosque entries with meaningful coverage on both shores, beyond the imperial core. Compare Edirnekapı/Üsküdar Mihrimah, Atik Valide, Çinili, Şemsi Paşa, Ortaköy and suitable modern examples such as Sancaklar without implying a complete list. Finish three approved mosque/craft 2.5D experiences and two true 3D exhibits total. Create four mosque routes varying size, period, distance and exertion. Include a clear craft/architect relationship graph that connects places without turning into another card grid. Recheck names/aliases to avoid duplicates.
Acceptance: 24 entries, 3+2 approved visual works and four routes satisfy their respective QA contracts. Routes avoid worship interruptions using dated guidance and sensible alternatives rather than invented live prayer availability.
Demo: compare a compact waterfront mosque and an imperial complex. Dimensions: D08, D10, D14, D16–D18, D23.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P16 — Museums, objects and collection-level storytelling

```text
Execute P16: Museums, objects and collection-level storytelling for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P15.

Start the museum wave with archaeology, Turkish and Islamic art, palace collections, maritime/industrial material and painting. Build 12 reviewed institution entries and separately modeled objects with inventory IDs, scale, provenance, current display uncertainty and period. Design an object plate that makes a detail or working principle understandable in 20–60 seconds. Produce two approved museum 2.5D works and one genuine 3D object/assembly exhibit. Connect an object to the Istanbul place/route it illuminates. Distinguish collection data from temporary exhibition data and do not promise an object is on display without confirmation.
Acceptance: institution and object search are distinct, inaccessible/rotating exhibits have graceful remote alternatives, scale is intelligible, and each visual object supplies more than decorative rotation.
Demo: an object reveals a mechanism or hidden face, then connects to a city story. Dimensions: D11, D12, D16–D18, D23.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P17 — Museums beyond the obvious and cross-city chapters

```text
Execute P17: Museums beyond the obvious and cross-city chapters for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P16.

Reach 24 reviewed museum entries across historic, modern/contemporary, house, island and district collections. Evaluate candidates such as Istanbul Modern, Pera, Arter, Sakıp Sabancı, Sadberk Hanım, Gazhane, Barış Manço, Adalar and Sait Faik against actual institution type and usable content. Complete three museum 2.5D works and two true 3D exhibits total, and four museum/mixed routes. Add rain-friendly, family-appropriate and short-visit choices based on observed access rather than generic labels. Handle temporary exhibitions with validity periods and archived states.
Acceptance: 24 institutions, 3+2 visual experiences and four routes meet review gates; no fabricated display claims or permanently hardcoded prices. Multilingual titles and place/object connections are navigable.
Demo: a small neighborhood institution holds its own beside a major museum. Dimensions: D08, D11, D14, D16–D18, D23.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P18 — Complete the 39-district discovery footprint

```text
Execute P18: Complete the 39-district discovery footprint for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P11, P15, P17.

Audit all 39 districts against the city register. Close factual/content gaps until the catalogue contains at least 90 distinct reviewed places and at least one meaningful place/story in each district. Retain the Byzantine→mosque→museum editorial priority, but use accurately labeled local/civic/landscape heritage where those categories would force weak or invented entries. Surface unknown/unvisited areas internally; do not fill the public atlas with empty coming-soon pins. Review long-distance travel expectations for Çatalca, Silivri, Şile, Tuzla and the islands. Produce district-level completeness counters automatically from validated records.
Acceptance: all 39 districts have reviewed content; 90 unique places and the three 24-entry category minimums are met without counting one site twice as two places. Publish a geographic-gap report in machine-readable form and summarize only the remaining exceptions here.
Demo: discover a worthwhile story in a randomly selected outer district. Dimensions: D08–D12, D15, D38.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P19 — The personal cabinet and a collectible experience library

```text
Execute P19: The personal cabinet and a collectible experience library for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P05, P08, P17.

Build a cabinet where users save artworks, places, routes and small discoveries. Give 2.5D/3D works identifiable covers, medium labels, a concise reason to open and optional short preview. Offer curated sets such as hands, water, domes, tile and hidden mechanisms, connected to actual content. Track viewed/discovered/visited separately; manual visits must remain possible without location. Add private notes, reorder, search, export/import and deletion. Avoid arbitrary rarity, streak pressure or pretending downloads are ownership. Make downloaded status and storage management understandable.
Acceptance: saves persist through restart and schema migration, a removed pack does not delete a memory, completed sets have meaningful endings, and the library remains quick with 500 saved fixtures. Inventory confirms the 12+6 approved experience targets; prototypes cannot count as approved.
Demo: build and revisit a personal three-piece collection. Dimensions: D15, D21, D22, D28, D34.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P20 — Narrated chapters and silent equivalents

```text
Execute P20: Narrated chapters and silent equivalents for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P09, P15, P17.

Produce at least 18 short authored stories attached to the visual collection, with a specific question, sequence and takeaway. Add Turkish/English narration where it improves understanding, synchronized detail focus, captions, transcripts, playback speed, pause/resume and offline delivery. Obtain human pronunciation review for Turkish and historical names. Sound starts only intentionally; support Android audio focus, interruption, headphones and silent site use. Keep narration separate from the motion timeline so reduced-motion users receive the same information. Do not add generic ambient sound merely to seem immersive.
Acceptance: all 18 stories have reviewed bilingual text, timed focus and silent equivalence; audio pauses correctly on interruption and resumes deliberately; missing audio does not block content. Track recording gaps externally without claiming temporary speech synthesis is approved final narration.
Demo: the same story understood with sound on and off. Dimensions: D23, D24, D29, D30, D32.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P21 — Honest Chora recognition and camera reliability

```text
Execute P21: Honest Chora recognition and camera reliability for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P01, P03, P04.

Audit ONNX preprocessing, camera sensor/display orientation, image picker EXIF, YUV row/pixel stride, supported formats, inference cancellation, foreground/background and permission recovery. Compare live and still preprocessing. Establish held-out capture-session/source splits and evaluate top-k recall, calibration, false acceptance, dark/blur/glare and lookalike negatives. Replace unsupported accuracy copy with reproducible evidence. Display tentative suggestions with confirmation and an easy browse fallback; percent softmax is not a probability of historical truth. Keep inference and preprocessing off interaction-critical work where profiling warrants it. Delete transient images unless the user chooses to keep them.
Acceptance: meet the recognition baseline before labeling it validated; denial/permanent denial, rotation, pause/resume and out-of-catalogue inputs never produce false certainty. If the dataset is unavailable, complete harness/UX and keep evaluation blocked, not passed.
Demo: correct suggestion, ambiguous scene and confident-looking wrong input handled honestly. Dimensions: D25, D26, D32, D33, D35.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P22 — Explicitly scoped recognition beyond Chora

```text
Execute P22: Explicitly scoped recognition beyond Chora for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P11, P15, P17, P21.

Evaluate whether expanded recognition adds value versus manual place selection/QR/deep-link entry. Prototype one additional place or object collection using an independently reviewed dataset and a place-aware retrieval/classification approach. Keep models versioned as optional packs; route predictions through stable content IDs and handle removed/reclassified items. Do not retrain a citywide model just by adding catalogued place names. Measure per-domain recall, non-catalogue rejection, latency, model bytes and failure recovery. Offer explicit manual context to reduce visual ambiguity; avoid inferring exact location from weak matches.
Acceptance: either a second clearly bounded domain passes the same held-out gates or the experiment is rejected with evidence and the app intentionally remains Chora-only for recognition. Rejected expansion is a valid product decision; disable unsupported claims and update the dimension's agreed scope explicitly rather than inflate coverage.
Demo: users always understand where recognition works. Dimensions: D25, D26, D20, D21.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P23 — Shareable discoveries and reliable return paths

```text
Execute P23: Shareable discoveries and reliable return paths for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P05, P19, P20.

Create tasteful user-initiated exports: a still comparison or 6–10-second authored reveal with the place, one fact, interpretation label and compact İzvoya mark. Support Android Sharesheet/save, cancellation, progress, offline generation and bounded render cost. Exclude private notes, location and other personal metadata unless explicitly selected. Link each share back to the exact place/detail; implement verified app links only with an owner-controlled domain and test fallback text/QR without it. Keep exported originals/restorations distinguishable. Draft share assets locally; do not post them or contact anyone.
Acceptance: export is legible in common portrait/square crops, cancellation frees resources, stale/missing links land somewhere useful, and a recipient can understand the discovery without the app. Test deep-link cold/warm starts and missing packs.
Demo: a discovery travels from detail to export to the same detail again. Dimensions: D27, D33, D43, D46.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P24 — Reasons to return without pressure

```text
Execute P24: Reasons to return without pressure for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P18–P20, P23.

Implement a small transparent recommendation system from chosen interests, saved discoveries, available time, district and already viewed material. Start with editorial rules, diversity and an explanation of why a chapter is shown. Distinguish nearby utility from remote inspiration; work without location/account. Add continue-reading, unfinished sets, a genuinely new chapter and optional quiet reminders requested by the user. Never present shuffled old content as new or add fake community counts. Let users reset personalization and disable all reminders. Instrument hypotheses locally for later consented measurement.
Acceptance: useful cold-start recommendations, no repeated dead-end items, understandable reasons, reliable opt-out and a meaningful completion state. Demonstrate three different interests using real release content.
Demo: returning after a week yields one credible next discovery. Dimensions: D05, D22, D28, D33, D39, D46.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P25 — Complete Turkish and English editorial delivery

```text
Execute P25: Complete Turkish and English editorial delivery for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P18–P20, P24.

Externalize UI strings and localize all release content, search aliases, metadata, maps/route labels, error states, accessibility labels, share exports and notifications. Review natural Turkish and English with humans; verify dotted/dotless I, sorting, pluralization, dates, distance, transliterated Greek names and mixed-script typography. Language switching must preserve context and downloaded content. Use a clear fallback for genuinely missing translations, with missing-key validation so fallback never conceals unfinished launch content. Preserve original object titles beside localized display names where helpful.
Acceptance: no untranslated release paths, no code concatenation producing broken grammar, no clipping at long translations/200% text, and equivalent historical meaning in both languages. Missing reviewers are external issues; machine translation alone cannot close editorial review.
Demo: switch languages mid-story, route and saved note without losing state. Dimensions: D07, D15, D23, D29, D31.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P26 — Accessibility and Android layout acceptance

```text
Execute P26: Accessibility and Android layout acceptance for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P03, P05, P12, P19, P20, P25.

Audit real app tasks with TalkBack, switch/keyboard navigation where supported, 200% text, high contrast, motion disabled, landscape and tablet/foldable widths. Ensure 48 dp targets, focus order, grouped semantics, labeled sliders, non-color-only status and visible focus. Give every 2.5D/3D hotspot a linear text alternative and every map a list route; preserve meaning in static mode. Verify caption timing, dark artwork control contrast, full-screen escape, orientation changes, safe areas, gesture navigation and predictive/system back compatibility on supported Android versions. Fix actual obstacles rather than add an accessibility checklist screen.
Acceptance: reveal/save/find-place/route/export can be completed without seeing motion or using pinch gestures; no blocked controls at 200% text. Record device/service versions, task results and remaining human test needs.
Demo: a complete story and route with TalkBack and reduced motion. Dimensions: D30, D31, D32.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P27 — Lifecycle, permissions, privacy and durable personal data

```text
Execute P27: Lifecycle, permissions, privacy and durable personal data for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P08, P19, P21, P23, P24.

Harden process death, activity recreation, camera/audio/render pause, background inference cancellation, rapid navigation and asynchronous disposal. Request camera/location/notifications only on relevant actions; handle denial, “don't ask again”, revocation and no hardware with useful alternatives. Define local-only defaults, photo retention, backup behavior, data export/delete, note durability and analytics consent boundaries. Make imports transactional and reject malformed/oversized input; validate remote manifests and app-link parameters. Add no secrets to the bundle and no broad storage permission for routine media selection. Inspect network behavior rather than asserting privacy from intent.
Acceptance: process-kill/restart restores useful state without resuming unwanted camera/audio; data export/delete works offline; denied permissions preserve browsing; note migrations and interrupted writes do not corrupt data. Record network/permission inventory and security findings in PROGRESS.md only.
Demo: an interrupted visit resumes safely with personal data intact. Dimensions: D32–D35.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P28 — Measured performance, installation size and thermal stability

```text
Execute P28: Measured performance, installation size and thermal stability for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P06–P08, P18–P21, P26, P27.

Profile release/profile builds on the agreed low/mid/high physical Android matrix; use measured frame timelines and memory rather than widget-test timings. Measure cold/warm startup, pack decode, scrolling, 2.5D playback, 3D interaction, camera inference, export and 20 scene open/close cycles. Reduce unnecessary rebuilds, offscreen rendering, pose allocation, texture residency and archive bundling. Verify KTX/geometry compression only where supported; adapt texture/mesh/motion quality with still fallback. Run a 15-minute thermal/battery session and slow-network/low-storage cases. Record p50/p95, device/OS, build ID, bytes and rejected optimizations.
Acceptance: the budget table is satisfied or revised explicitly with evidence and a product decision; no hidden reduction in visual correctness. Use official Flutter/Android profiling guidance current at execution time. Missing physical hardware remains an external validation gap.
Demo: before/after traces and the same attractive experience on the floor phone. Dimensions: D18–D21, D31, D32.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P29 — Editorial operations and recoverable content updates

```text
Execute P29: Editorial operations and recoverable content updates for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P04, P08, P18, P25.

Build the smallest local/editor workflow that supports draft→review→publish→archive, bilingual validation, source freshness and preview on Android. Avoid a full custom CMS unless team needs justify it. Produce versioned manifests, asset integrity checks, reviewer ownership, scheduled staleness queues and rollback to a known-good pack. Handle changed opening hours, moved objects, renamed places and corrections without app updates or broken saved IDs. If hosting is unavailable, complete local packaging and a fake-server recovery demonstration; leave deployment blocked on explicit credentials/budget.
Acceptance: add a new place without editing a Flutter screen, preview it, detect an invalid source/translation, publish to the test endpoint, then roll back while preserving saves. A responsible reviewer and correction cadence are named for each launch chapter.
Demo: a museum closure becomes a useful alternative instead of a broken itinerary. Dimensions: D06, D07, D12, D19, D38, D45.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P30 — Desirability study and distinctiveness review

```text
Execute P30: Desirability study and distinctiveness review for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P18–P20, P23–P26.

Prepare and run the 30-person resident/visitor/remote study defined in the contract, with first-use reveal/save/find-place tasks and a week-later follow-up. Include participants with relevant access needs. Compare restrained 2.5D, expressive figure motion and genuine 3D on matched content; counterbalance order. Measure time to discovery, completion, interpretation comprehension, voluntary reopens/saves, specific reasons to return and discomfort/confusion. Ask participants to describe the product and recall its mark/layout without prompting. Separate novelty from repeat value; do not equate watch time with understanding. Prepare recruitment materials but do not contact people without explicit authorization.
Acceptance: sample size and limitations are visible, thresholds meet the contract, and observed problems are fixed and retested. Without participants, finish the protocol and prototypes but keep desirability unvalidated. Retire weak visual pieces instead of adding quantity.
Demo: the product's strongest moments supported by observed behavior. Dimensions: D01, D03, D05, D16–D18, D28, D40.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P31 — Consent-based measurement and acquisition experiments

```text
Execute P31: Consent-based measurement and acquisition experiments for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P23, P24, P27, P30.

Implement a small documented event model for first reveal, completed story, save, route start/completion, voluntary return and share intent. Distinguish an OS share action from a confirmed recipient open. Use opt-in pseudonymous events, local batching, no raw photos/notes/precise location and configurable retention/delete; test opt-out network silence. Build a local/fake-data funnel first and a real dashboard only with approved hosting. Draft three distinct acquisition experiments: a striking art reveal, a practical short route and an overlooked neighborhood discovery, in Turkish/English. Define audience, hypothesis, exposure denominator, success metric and stopping rule. No unsolicited publishing or ad spend.
Acceptance: event duplication/versioning is tested, success metrics can be computed, and privacy behavior matches actual traffic. Record measured results separately from targets; no invented analytics or generic virality claim.
Demo: trace one consenting journey through the funnel and its locally prepared share creative. Dimensions: D27, D28, D33, D39, D46.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P32 — Automated Android quality and reproducible builds

```text
Execute P32: Automated Android quality and reproducible builds for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P27–P29.

Add proportionate CI/local checks for schema migrations, source/pack validation, deep links, permission errors, catalogue/notes, recognition preprocessing, viewer asset lifetimes, geometry and Android smoke journeys. Use visual assertions for meaningful layout states without brittle pixel tests that mirror implementation. Pin/review toolchains and dependencies, cache responsibly and verify reproducible build inputs. Preserve originals and require failed checks to block a release candidate. Establish severity definitions, regression triage and recovery tests for corrupted packs. Generate machine-readable evidence, not extra Markdown reports. A remote CI service may remain unconfigured while equivalent local scripts run.
Acceptance: a clean checkout can resolve/build/test the Android app; deliberately invalid content and a meaningful regression fail the gate; the current release candidate passes. Do not report historic test counts as current results.
Demo: a detected regression, fix and green repeatable pipeline. Dimensions: D19, D34–D37, D43.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P33 — Field trials and release-candidate stability

```text
Execute P33: Field trials and release-candidate stability for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P13, P15, P17, P26, P28–P32.

Run all 12 routes through a field-validation programme and the 14-day Android pilot with at least 20 opted-in testers/500 sessions. Include daylight/glare, interiors, weak GPS, offline travel, ferries, stairs, denied permissions, low battery, interruptions and closed entrances. Check map pins at the actual entrance, visit-duration estimates, etiquette, translations and content truthfulness. Sample supported recognition scenes with real photos and out-of-domain negatives. Triage crashes, ANRs, visual artifacts, inaccessible tasks and misleading information by severity, then retest fixes on affected devices. Never label a desktop screenshot or emulator run a physical field pass.
Acceptance: crash-free target and task/research gates hold, every published route is field-reviewed or explicitly removed from release scope with a corresponding score/scope change, and no critical/high-impact issue remains unresolved. If testers are unavailable, record exact unperformed checks and continue only independent fixes.
Demo: a complete real visit works from arrival to saved memory. Dimensions: D12–D14, D20, D25, D26, D32, D36, D40, D41.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P34 — Sustainable release offer, store assets and support

```text
Execute P34: Sustainable release offer, store assets and support for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P30, P31, P33.

Decide the release offer using observed value and operating cost: start with a free useful core; evaluate optional curated packs only if the owner chooses paid distribution. Do not implement subscriptions or accounts without evidence/decision. If payment is selected, add Android billing restore/error/offline entitlement paths and budget their validation; otherwise explicitly record no billing at launch. Prepare accurate Turkish/English store copy, custom icon crops, phone screenshots and a short preview showing actual shipped interactions. Draft support contact, correction/report flow, FAQ within the app and privacy/data declarations matching measured behavior. Prepare assets locally; no publishing or outreach.
Acceptance: the offer has an owner decision, no fake social proof/coverage claims, screenshots match the candidate, all support paths work, and operating-cost assumptions have an accountable owner. Public asset clearance remains the owner's deferred pre-publication decision.
Demo: a truthful store preview and a complete support/correction journey. Dimensions: D01, D02, D42, D44–D46.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

### P35 — Signed Android candidate, rollback and ship decision

```text
Execute P35: Signed Android candidate, rollback and ship decision for the Android-only İzvoya app.
Read PHASES.md and PROGRESS.md and follow their product contract, budgets and scoring rules.
Dependencies: P00–P34 with accepted scope decisions; close the remaining signing/store/recovery gates in this phase.

Create a production-signed Android App Bundle only using owner-provided signing/publisher setup; never commit keys or invent credentials. Confirm final package ID, versioning, minimum/target SDK, native library/page-size compatibility and current Play requirements at execution time using official sources. Test install, in-place update, backup/import, asset delivery and signing on the supported device matrix. Prepare an internal-testing rollout and a recovery plan for binary/content failures; validate actual rollback constraints rather than promising Android downgrades. Reconcile every dimension against its 100% gate and close all release-blocking external issues. Distinguish a debug-signed release APK from a distributable production candidate.
Acceptance: the exact signed candidate has fresh passing evidence, truthful store/support/privacy material, owned content operations and a tested recovery path. All dimensions at 100% plus no release blockers means ready to ship this bounded Android release, not automatically published. Present the concrete candidate and rollout for the owner's final publication decision; do not publish automatically.
Demo: clean install and upgrade of the final candidate with the complete release evidence. Dimensions: D35–D46 and final audit of D01–D34.

Finish by updating PHASES.md (dependencies/decisions and the Open issues section, including newly found, resolved or changed outside-intervention needs) and PROGRESS.md (phase status, affected dimension percentages before→after, evidence/commands, remaining gaps and next phase). Record zero gain when unverified; never invent a passed check. Keep all planning/progress prose in these two files only.
```

## Open issues requiring outside intervention

Only dependencies requiring the owner, external people, credentials, access or an external-state change belong here. Ordinary coding bugs belong in the relevant phase's remaining work in `PROGRESS.md`. Status values: Open / Waiting / Resolved / Deferred. An open issue blocks only the named acceptance gate, not all independent work. Update this section after **every phase**, even when the change is “reviewed; unchanged”. Do not ask again for actions already authorized.

| ID | Status / severity | Outside owner and exact needed intervention | Affected phases / unlock | Work that can continue |
| --- | --- | --- | --- | --- |
| O01 | Open / validation blocker | No Android device connected at audit. Project owner supplies access to low/mid/high physical Android phones (including proposed 4 GB floor), OS details and permission to run field measurements. | P07, P21, P26–P28, P33, P35; D20/D31/D32/D41/D43 cannot reach 100% without device evidence. | Emulator/widget tests, profiling harness, asset budgets and still fallbacks. |
| O02 | Open / content gate | Owner arranges a Byzantine/art-history reviewer and Turkish/English editors; reviewers verify disputed identifications, narrative and translation. | P04, P09–P11, P14–P18, P20, P25, P29; editorial 100% gates. | Source collection, draft content, validators and labeled uncertainty. |
| O03 | Open / acquisition gate | Owner provides or arranges adequate imagery, multiple views/scale references for the selected six 3D exhibits, optional site access and field captures. Existing Chora sources support only the current scope. | P06/P07, content waves, P21/P22; visual fidelity and real recognition evaluation. | Authoring tools, clearly labeled study geometry, synthetic test fixtures; no invented measured surfaces. |
| O04 | Open / service gate | Owner selects hosting/map spend ceiling and provides relevant accounts/keys and an app-link domain when ready. No service/domain is assumed purchased. | P08, P12, P23, P29, P31; production download/map/link/analytics behavior. | Offline starter, list map fallback, local test server, URL routing and export without verified links. |
| O05 | Open / human evidence gate | Owner authorizes recruitment/contact or supplies 30 study participants and 20 pilot testers (groups may overlap), including appropriate accessibility/visitor contexts. | P30/P33; real desirability, repeat value and stability evidence. | Protocol, consent screens, recordings setup, prepared invitations; no automatic outreach. |
| O06 | Open / signing gate | Owner supplies publisher account, final identity ownership decision, signing setup and secure access for the concrete release candidate. | P35; production signing/internal-track acceptance. | Debug-signed release build, package verification, store drafts and local QA. |
| O07 | Deferred / offer decision | Owner chooses free-only versus paid packs and accepts an operating-cost budget after research. Default development assumption: free useful core, no billing or mandatory account. | P34; sustainable offer; does not block current prototype work. | Cost model and value experiments; no subscriptions invented. |
| O08 | Deferred / publication gate | Owner decides when to publish, handles the requested deferred public-asset/brand clearance and approves the concrete rollout. No present copyright-clearance phase is required. | P35/public release only. | All private development, visual experiments and review artifacts. |
| O09 | Open / operations gate | Owner names the person responsible for content updates, support/corrections and source/visit-data review cadence. | P29/P34; operational readiness cannot be awarded to an unstaffed process. | Build the tools, stale-data queue and in-app correction workflow. |

## Reference anchors

Sources checked 2026-09-26; candidates and technical choices still require phase-specific verification. No opening time, fee or public access is guaranteed by this plan.

- Historical layering and monuments: [UNESCO Historic Areas of Istanbul](https://whc.unesco.org/en/list/356/) and [official Ayasofya cultural record](https://www.kulturportali.gov.tr/turkiye/istanbul/gezilecekyer/ayasofya-muzesi).
- Municipality coverage: [İBB jurisdiction](https://ibb.istanbul/ibb/belediye-hakkinda/yetki-alani/). Current visit data should come from operators, for example [Istanbul Modern visitor information](https://www.istanbulmodern.org/en/visit/museum); do not reuse time-sensitive details without a check date.
- Android quality and identity: [Android technical quality](https://developer.android.com/quality/technical), [adaptive icons](https://developer.android.com/develop/ui/compose/system/icon_design_adaptive), [Flutter performance practices](https://docs.flutter.dev/perf/best-practices).
- 3D delivery: [glTF specification](https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html) and [KTX texture delivery](https://www.khronos.org/ktx/). These support evaluation of formats, not an untested renderer recommendation.

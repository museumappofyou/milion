# Interactive scenes and separate restoration studies

Both **Anastasis (F02)** and **Last Judgment (F05)** now open the shared scene
explorer. Existing originals, v5 relief images, diagnostic views and source
photographs remain unchanged.

The current **Restored** view uses [separate 4K v2 restorations](v2/README.md) at
100% strength. The four earlier studies described below remain available.

## Explore

- Pinch, double-tap, mouse-wheel or trackpad zoom; plus/minus buttons; 1×–8×.
- Drag to pan. Reset returns to the complete scene. The image stays bounded.
- Tap a numbered marker or a named detail chip to animate to that part and
  read its description. Markers disappear when examining a detail so they do
  not cover faces. Six details per scene.
- **Animate figures** moves heads, hands, arms, robes and angel wings using
  the existing painted figures. **Pause figures** freezes the current pose;
  **Still** returns the figures to the exact original pose without changing zoom.
  The **Pose** slider lets the user examine any point of the six-second loop.
  This works with Original, Relief and Restored. Details and zoom remain manual.
- Motion starts off, respects reduced-motion settings, and pauses when leaving
  the screen or backgrounding the app. Manual poses remain available.
- See [figure animation](../figure_animation/README.md) for joints, validation
  and current app captures. The earlier tour and whole-surface rocking controls
  have been replaced by figure animation.
- **Scene options → Classic v5 viewer** opens the preserved static screen, with
  its original diagnostics and, for Anastasis, its archived v3 renderer.

## Earlier restoration experiments (preserved)

Four new files were produced with the **built-in image_gen tool**, using the
full scene and an independent closer reference for each fresco:

| Study | Existing source | Separate generated file |
|---|---|---|
| Anastasis, full scene | `assets/anastasis/conch_reference.jpg` | `assets/restoration/anastasis_scene_study.png` |
| Anastasis, Christ detail | `assets/anastasis/detail_christ_mandorla.jpg` | `assets/restoration/anastasis_detail_study.png` |
| Last Judgment, full vault | `assets/last_judgment/vault_reference.jpg` | `assets/restoration/last_judgment_scene_study.png` |
| Last Judgment, Deesis detail | `assets/last_judgment/deesis_reference.jpg` | `assets/restoration/last_judgment_detail_study.png` |

The exact final prompts, tool mode and original generated-file locations are in
[prompts.json](prompts.json). The prompts request gentle cleanup and clearer
surviving facial features while retaining Byzantine style, composition, major
losses, patina and credits. The generated results are stronger than minor
cleaning at full strength, so these earlier studies start at a **35%** blend when selected in Restoration
studies. The new 4K studies start at 100%. Users can adjust it from 0–100%. Neither this blending
nor any viewer interaction writes back into the image files.

These are interpretive restoration studies, not evidence of recovered original
paint. Facial detail is inferred; small registration differences and changes to
fine strokes can remain. The studies are labeled in the app. Full-scene studies
are available through **Original / Relief / Restored**. The separate close-up
file comparisons are under **Scene options → Restoration studies**, with their
own zoom and Original/Study controls. Major loss bands remain visible.

[original_asset_hashes.json](original_asset_hashes.json) records SHA-256 hashes
of every existing Anastasis and Last Judgment asset before this work.
[original_preservation_report.json](original_preservation_report.json) verifies
those originals remain byte-for-byte identical.

## Implementation and checks

- Shared controls and lifecycle: `lib/screens/scene_explorer_screen.dart`.
- Connected surface: `lib/widgets/interactive_relief_surface.dart`.
- Hotspot coordinates and source/study pairs: `lib/models/explorable_scene.dart`.
- Bounded-lifetime decoded textures: `lib/services/explorer_assets.dart`.
- Separate file comparisons: `lib/screens/restoration_studies_screen.dart`.
- Classic viewers: `anastasis_v5_screen.dart`, `last_judgment_v5_screen.dart`.
- `tool/prepare_explorer_geometry.py` samples existing v5 height data into compact
  grids (11,310 and 14,065 vertices). It does not modify photographs.

```sh
python3.11 tool/prepare_explorer_geometry.py
flutter test --no-pub
flutter test --no-pub tool/interactive_scene_screenshot_test.dart
flutter analyze --no-pub
flutter build web --no-pub
flutter build apk --release --no-pub
```

The interaction tests cover both scenes, pinch, double-tap, mouse-wheel, bounded
zoom, pan, figure movement with a stationary camera, frozen paused poses,
reduced motion, disposal, restoration controls and access to classic v5.
[Flutter previews](flutter/) cover 360×800, 390×844, 430×932 and 1440×900, plus
zoomed original/relief/restored comparisons, motion and close reference studies.
These are widget captures; physical-device performance has not been measured.

## Verified result

The original restoration release passed 31 application tests and its screenshot checks.
Current figure animation validation is recorded in [its report](../figure_animation/README.md).
That release also passed
Flutter analysis and Web/Android release builds. The APK contains all four
restoration images and both geometry files, verified against their workspace
hashes. The preservation
check confirms all 386 pre-existing scene assets retain their original hashes.

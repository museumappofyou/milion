# Separate 4K restorations

Both scenes open at full strength when **Restored** is selected. **Original**,
the 0–100% Restoration slider, and all earlier gentle/close-up studies remain
available. No original image or Classic v5 asset was replaced.

| Scene | App export | Native generated image |
|---|---|---|
| Anastasis | [3840 × 2046 JPEG](../../assets/restoration/anastasis_restored_4k_v2.jpg) | [1718 × 916 PNG](native/anastasis_restored.png) |
| Last Judgment | [3840 × 2560 JPEG](../../assets/restoration/last_judgment_restored_4k_v2.jpg) | [1536 × 1024 PNG](native/last_judgment_restored.png) |

The **built-in image_gen tool** produced the restorations from the original
whole-scene photographs. Prompts requested fully reconstructed faces, garments
and damaged paint while preserving Byzantine style, the composition, figure
positions, architecture and framing. These are interpretive reconstructions;
missing facial details and paint are inferred. Small changes to individual
strokes and facial features remain possible.

The generator returned the native sizes above. `sips` resampled those results
to 3840 pixels wide and exported JPEG at quality 95. These are **upscaled 4K
exports, not native 4K generations**; resampling does not recover extra historical
detail. Native generated files are retained unchanged.

- [Exact final prompts and tool mode](prompts.json)
- [Dimensions, source/export paths and SHA-256 manifest](manifest.json)
- [Original preservation check: 386 pre-existing files](original_preservation_report.json)
- [Stronger figure animation and app captures](../../figure_animation/v2/README.md)

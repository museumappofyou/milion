# Anastasis fourth pass: geometry validation, **not accepted for the app**

> Superseded by the [fifth pass](../v5/README.md), which the app now uses.

The existing Chora scene-detector feature still loads `assets/anastasis/relief_v3/manifest.json`. This directory is a fixed-camera, no-animation geometry branch. Its phone-size comparisons show that the fourth-pass acceptance criteria are **not met**. The experimental meshes and masks are intentionally not wired into the mobile viewer; doing so would replace one weak still frame with another.

## Current renderer diagnosis

This repository is a **Flutter** application, not a Three.js scene. `PhotoReliefProjector` in `lib/services/anastasis_relief.dart` builds uniform textured grids and `AnastasisDomeView` draws them with `Canvas.drawVertices` in painter order. There is no hardware Z buffer or authored triangle topology for each painted rock. At the centered camera, the projector deliberately keeps every vertex on the same source photograph pixel. Semantic Z therefore has **zero frontal parallax**. Only baked lit PNGs, narrow contact maps, and vertex color modulation can show still-image relief. The source photo underneath prevents black gaps but can reappear as a duplicate when foreground geometry shifts.

The v3 manifest has 19 masks. Its 3 left and 3 right rock bands use a 13-master-pixel grid, local amplitudes `.018–.020`, height-map Sobel normals, baked matte lit textures, and alpha-cropped masks. Its crowd bands use a 30-pixel grid, local amplitudes `.006–.010`, and the same alpha rendering path. Adam and Eve use `.013` local amplitude and Christ `.018`, on a 19-pixel grid. Defaults are in the [v3 manifest](../../assets/anastasis/relief_v3/manifest.json) and [v3 diagnosis](../v3/README.md). All have complete source RGB behind them. The principal issue is structural, so multiplying the shared relief or parallax controls is not an adequate fix.

| Current object | Source mask | Current mesh / normals | Z | Still-frame finding | Needed action |
| --- | --- | --- | ---: | --- | --- |
| Left rock back/mid/front | Three v3 rock masks | Uniform grids, smoothed height normals | .075/.112/.153 | Broad slabs, ridges barely visible at 390 px | Trace individual painted rock facets and crests more accurately |
| Right rock back/mid/front | Three v3 rock masks | Same | .077/.114/.155 | Better painted ridge contrast, still mostly flat | Correct polygon topology and hand tune normals |
| Left rear/mid/front crowd | Three v3 crowd masks | Uniform grids, shallow body maps | .190/.232/.280 | Front mask includes several witnesses as one region | Retouch figure overlap contours; separate meaningful witnesses |
| Right rear/mid/front crowd | Three v3 crowd masks | Same | .192/.234/.282 | Broad clustered robes and heads remain fused | Retouch constituent silhouettes and contact receivers |
| Adam / Eve | V3 individual masks | 19-pixel grids, Sobel normals | .352/.354 | Z is mostly invisible when camera is centered | Correct support shadow and edge continuation |
| Mandorla / Christ | V3 individual masks | 19-pixel Christ grid, alpha texture | .308/.438 | Best foreground cue, but slight moves expose duplicate source beneath | Fill only tiny proven disocclusion margins or further constrain view |
| Base fresco | Complete master photograph | Flat image | 0 | Prevents empty holes; also carries duplicated painted foreground content | Preserve as backing; do not invent large hidden regions |

## Experiments built

### 1. Connected authored rock meshes

`tool/connected_relief_proto.py` and `tool/connected_right_proto.py` define master-photo `x,y,z` vertices and shared-face triangles (23 left, 24 right). The triangles keep original RGB UVs, with no generated or repainted texture. Two triangles in the same authored quadrilateral share one normal, so the diagonal used for triangulation is not lit as a painted crease. Selected painted crests receive short soft shadow strokes. A complete source photograph remains beneath each mesh. The left and right depth and normal images, JSON mesh topology, centered renders, debug raking light, and 45° views are in this directory:

- [Left original](left_rock_original.png), [geometry](left_rock_geometry.png), [normals](left_rock_normals.png), [front](left_rock_front.png), [raking light](left_rock_raking_light.png), [side](left_rock_side45.png), [mesh](left_rock_mesh.json).
- [Right original](right_rock_original.png), [geometry](right_rock_geometry.png), [normals](right_rock_normals.png), [front](right_rock_front.png), [raking light](right_rock_raking_light.png), [side](right_rock_side45.png), [mesh](right_rock_mesh.json).

The rock side views prove there is connected non-flat geometry. The exaggerated light proves adjacent authored facets respond differently. **They do not pass visual QA:** several authored edges cut across painted rock planes; the left mesh begins over an uncertain figure/rock transition; and debug lighting exposes artificial polygon patches. At the intended production light clamp (`.88–1.08`), the [left](left_mobile_comparison.png) and [right](right_mobile_comparison.png) 390-pixel static crops are only modestly different from the current version. The reversible contrast pivot in the rock prototype acts on *photographed RGB* to compensate for the master’s pale exposure, but it cannot fix plane placement.

### 2. Three overlapping witnesses

The rejected `tool/figures_relief_proto.py` used individual GrabCut polygons and produced clipped-card silhouettes. `tool/figure_cluster_proto.py` instead partitions the existing painted outer group mask into three bands; their lossless masks are `left_witness_{rear,middle,front}_mask.png`. [The color review](figures_masks.png) does show three bands, but its divider crosses a halo and robes. A separate continuous-depth experiment in `tool/figures_continuous_proto.py` smooths those uncertain internal steps and adds shallow authored head/torso domes. It preserves the original pixels better, but its [static phone comparison](figures_mobile_comparison.png) still does **not** reveal rear/middle/front convincingly. Its side renderer also has raster cracks; [figures_side45.png](figures_side45.png) is not an acceptable geometry proof. Neither figure technique is production ready.

### 3. Christ and mandorla

`tool/christ_relief_proto.py` uses the existing Christ and mandorla masks over the complete master image. The [front render](christ_relief.png) preserves the composition, but the [45° debug view](christ_side45.png) exposes a duplicated source Christ behind the raised one. This cannot be hidden with a dark painted crescent. Only conservative backing continuation within a very small allowed view envelope can be defended from existing pixels. This prototype fails the seam/disocclusion gate.

### Full segmentation review

[semantic_layers.png](semantic_layers.png) and [its phone-width copy](semantic_layers_390.png) show the inherited 19 regions plus three candidate left-witness divisions. The image is deliberately diagnostic: the broad right-side masks and the straight cuts through the left witness group are visible. Distinct colors alone are not sufficient to accept the segmentation.

## Quality gates and decision

| Gate | Result | Evidence |
| --- | --- | --- |
| Multiple figure depth clusters with trustworthy boundaries | **Fail** | [Color mask](semantic_layers.png) splits the left group but cuts painted forms; right groups remain broad |
| Authored left and right rock topology | **Partial** | Both connected mesh JSON files and side views are real geometry, but several vertices miss the painted facets |
| Coherent raking light on rock planes | **Fail** | Debug light reveals misregistered polygon patches; production light is too faint at 390 px |
| Three figures separate in static front view | **Fail** | [Comparison](figures_mobile_comparison.png) reads almost like the original |
| Christ backing has no duplicate or seam | **Fail** | [Christ side view](christ_side45.png) shows the duplicate underpaint |
| Centered 390 × 844 full scene reads as a physical relief | **Not attempted** | The user’s prototype gates require the three parts to pass before assembly |
| App integration / FPS | **Not attempted** | V3 app remains the working baseline; no V4 phone/GPU claim is made |

The deliberately stronger debug raking-light render is **not** a production candidate. Source photographs were read only; no original image or existing Gaussian-splat asset was changed. V4 RGB comes from `assets/anastasis/conch_reference.jpg`. `web-ke-01-CAN09421.jpg` provided a locally registered figure guide, never composited RGB. `webke_registration_overlay.jpg` shows why a single global homography is unreliable on the curved apse; `left_webke_local_aligned.jpg` is useful only for local tracing.

## Regenerate the experiments

Run from the repository root with Python 3.11, NumPy, OpenCV and Pillow:

```sh
python3.11 tool/connected_relief_proto.py
python3.11 tool/connected_right_proto.py
python3.11 tool/figures_continuous_proto.py
python3.11 tool/christ_relief_proto.py
python3.11 tool/compare_anastasis_v4_prototypes.py
```

The two superseded figure scripts remain for provenance but are not in that command sequence. No app build is needed to inspect these fixed-camera images.

## Next corrections, ranked by expected visual impact

1. Trace **painted** crest and facet boundaries on the high-resolution reference, with a mobile-size preview alongside each edit. Rebuild both meshes from those contours; current triangles are too broad.
2. Retouch witness silhouettes and actual overlap lines one figure at a time. Split by painted edges, not by vertical interpolation curves. Review flat semantic colors before adding relief.
3. Give those corrected figure masks short directional contact shadows only on supported overlaps. Then validate a centered phone still before implementing a side view or motion.
4. Resolve Christ/mandorla disocclusion within a documented narrow margin. Keep the complete source backing; do not synthesize large hidden painted areas.
5. Once all three local prototypes pass, extend the Flutter renderer to consume authored facet vertex/triangle data and integrate the mobile full scene. Measure a real device’s raster time and memory then.

**Fourth-pass status: incomplete.** The experimental work makes the failure observable and provides a better rock topology starting point, but the fixed 390-pixel image is not yet the requested physical painted relief.

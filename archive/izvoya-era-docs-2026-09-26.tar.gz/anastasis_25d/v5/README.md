# Anastasis fifth pass: authored relief geometry, static frame

This pass replaces the fourth-pass experiments. The camera is fixed and centered. Automatic motion, Christ animation, gyroscope, parallax easing, drift, animated light, layer breathing and hover are all off. The app's painted-relief screen now shows this static frame by default. `tool/mobile_relief_v5_screenshot_test.dart` drags the viewer and asserts the frame does not change by a single pixel.

## Architecture: one surface, not a collage

The v3/v4 renderer stacked transparent cut-outs over a copy of the photograph. That design causes the dark mandorla crescent, the duplicated Christ in side view and ghosting at mask edges. V5 instead builds **one continuous height field on the master photograph's pixel grid** (`assets/anastasis/conch_reference.jpg`, 2048×1091). Every fresco pixel appears exactly once, at its own depth:

- Imperfect mask edges cannot open holes, because nothing is cut out.
- Nothing appears twice, so there are no transparent ghosts or double images.
- A step between layers is a vertical wall of the same surface. In the 45° views it shows as a wall, colored by conservative edge continuation (a darkened, desaturated copy of the edge pixel). It never shows empty space.

This meets the brief's "complete base fresco under every layer" intent more strictly than a backing copy would. There is no backing copy to leak through.

Final color is `originalRGB × reliefLight × contactShadow × occlusion`:

- `reliefLight = clamp((ambient + (1-ambient)·N·L) / flat, 0.88, 1.08)`, with ambient 0.38 and light (−0.45, −0.60, 0.66) from the upper left at 41° elevation.
- Across the full frame, the pixel ratio relief/original is 1.00 at the median, 1.048 at the 95th percentile and 1.078 at the 99th percentile. Nothing is recolored or tinted.
- Values below 1 come from the cast contact shadows and crevice occlusion. 32% of fresco pixels change by more than 3%.

The debug light uses the same azimuth at 22° elevation with a 0.62–1.38 clamp. It is only for diagnosis.

## Semantic depth clusters — hard gate

[semantic_layers.png](semantic_layers.png) (with legend: [semantic_layers_labeled.png](semantic_layers_labeled.png), phone width: [semantic_layers_390.png](semantic_layers_390.png)).

| Cluster | Left side | Right side | Base z |
| --- | --- | --- | ---: |
| Rear figures (purple) | rear heads, rear halos, lavender figure | rear heads, tan figure | 30–34 |
| Middle figures (blue) | David, mauve figure, red band, grey band | ochre bowed figure, Abel | 37–45 |
| Front figures (green) | Solomon, John the Baptist | brown figure, figure rising from tomb | 44–52 |
| Adam / Eve (orange) | Adam | Eve | 56 |
| Mandorla (cyan) | — | — | 40 |
| Christ (red), halo | — | — | 70 / 74 |
| Rock back / mid / front (yellows) | 14 authored facets | 16 authored facets | 3–30 |
| Ground, tombs, gates, pit, Hades | tomb | tomb | 24–47 |

Z is in master pixels toward the viewer. The painted overlap order sets the order in [layers.json](authoring/layers.json). A part is also raised 2 px above the 97th percentile of whatever it overlaps, so an overlapping shoulder always clears the body behind it.

The masks were authored with Segment Anything (ViT-H) point and box prompts, using `tool/anastasis_v5_sam_masks.py` and [sam_prompts.json](authoring/sam_prompts.json). Hand polygons then corrected the halos, Christ's feet, the dark hems, the grey band and the right tomb face. The committed masks in `authoring/sam/` are the source of truth, so the build does not need SAM or its 2.5 GB checkpoint.

## Prototype 1 — mountains as authored facets

The rock is built from polygons traced on the painted planes in [rock_facets.json](authoring/rock_facets.json), not from a uniform grid or pigment displacement:

- 14 facets and 7 authored overlap steps on the left; 16 facets and 8 steps on the right.
- Each facet has a band (back/mid/front) and a facing direction.
- Pale painted planes lean toward the upper-left light; dark planes lean away from it.
- Every shared facet edge is snapped onto the strongest painted stroke within 7 px, using a ridge filter on the photograph.

A sparse gradient-domain solve then fits the surface:

- Inside a facet the surface is a plane with the authored tilt.
- A shared edge is a sharp crease.
- An authored overlap is a step of dz px.
- The solved tilts track the authored ones; see `*_rock_facets_solved.json`.

Normals are flat per facet with discontinuities at creases, not smoothed.

| | Left | Right |
| --- | --- | --- |
| Original | [left_rock_original](left_rock_original.png) | [right_rock_original](right_rock_original.png) |
| Facets, bands, steps, facing | [left_rock_geometry](left_rock_geometry.png) | [right_rock_geometry](right_rock_geometry.png) |
| Normals | [left_rock_normals](left_rock_normals.png) | [right_rock_normals](right_rock_normals.png) |
| Height | [left_rock_depth](left_rock_depth.png) | [right_rock_depth](right_rock_depth.png) |
| Production front | [left_rock_front](left_rock_front.png) | [right_rock_front](right_rock_front.png) |
| Debug raking light | [left_rock_raking_light](left_rock_raking_light.png) | [right_rock_raking_light](right_rock_raking_light.png) |
| 45° (relief ×2) | [left_rock_side45](left_rock_side45.png) | [right_rock_side45](right_rock_side45.png) |

The rock prototypes are rendered **rock only**. Figure areas are filled by continuing the rock surface, but they still show the figures' painted pixels.

Under the debug light:

- **Left crown:** the lit west face of the peak, its top plane and the lobe respond as different planes. The crest step and the lit-face/white-ledge step cast short shadows.
- **Right crown:** the end block's lit face, dark underside and top plane read as a faceted cantilever that casts onto the wall below.

## Prototype 2 — three overlapping figures

[figures_original](figures_original.png) · [figures_masks](figures_masks.png) (per-figure outlines on the cluster colors) · [figures_front](figures_front.png) · [figures_raking_light](figures_raking_light.png) · [figures_side45](figures_side45.png).

The prototype stacks the left rear heads, David (middle) and Solomon (front). Each figure is a raised part with three features:

- a 4–5 px rounded edge;
- a shallow 3 px body swell (the robe folds keep their painted look);
- a soft head dome.

There is no anatomy modeling, no outline, no glow and no transparency. In the static front view, the order of the figures comes from occlusion plus a short cast shadow on the lower-right of each overlap. Most shadows are a few pixels wide at phone size.

## Prototype 3 — Christ and mandorla

[christ_original](christ_original.png) · [christ_relief](christ_relief.png) · [christ_raking_light](christ_raking_light.png) · [christ_side45](christ_side45.png) · [christ_parallax_test](christ_parallax_test.png) (±6° yaw, ±4° pitch).

- Christ is the highest part, at z 70–78. His halo is a separate disc behind his head.
- The mandorla is a low, rounded plate at z 40, raised above the sky and rock.
- The parallax test shows side walls, not a dark crescent or a duplicated Christ. That seam cannot occur in this architecture.

## Full scene

- Static renders: [full_front](full_front.png), [full_raking_light](full_raking_light.png), [full_depth](full_depth.png), [full_normals](full_normals.png), [full_shadow_ao](full_shadow_ao.png), [full_side45](full_side45.png).
- Real Flutter widget captures in [flutter/](flutter/): `relief_390x844`, `original_390x844`, the figures/left rock/right rock focus views, each with an original pair, plus 360×800, 430×932 and 1440×900 desktop. The block glyphs in UI text are the test environment's font substitution.
- Software stand-ins: `static_*_software.png`.
- [diagnostic_current_vs_new.png](diagnostic_current_vs_new.png) compares CURRENT (the v3 app composite) with NEW for the left mountain, right mountain, left figures, right figures, center and full scene. All panels are static.

## Checklist

| Gate | Status | Evidence |
| --- | --- | --- |
| Semantic masks contain multiple figure depth clusters | Pass | rear/middle/front on both sides, plus Adam/Eve, mandorla and Christ; also asserted in `test/anastasis_relief_v5_test.dart` |
| Left mountain has authored physical facets | Pass | 14 facets, 7 steps; geometry sheet and side view |
| Right mountain has authored physical facets | Pass | 16 facets, 8 steps |
| Mountain normals follow rock planes | Pass | per-facet flat normals with creases |
| Ridges respond to raking light | Pass (debug); subtle at production clamp | raking vs front renders |
| Figures have a real occlusion hierarchy | Pass | figures_side45, full_side45 |
| Adam/Eve separate from the surrounding figures | Pass | z 56 over the front clusters at ≤52 |
| Christ is the strongest foreground layer | Pass | z 70–78, highest in the scene |
| Mandorla dark seam gone | Pass (structural) | no cut-outs; christ_parallax_test |
| No disocclusion holes | Pass (structural) | single surface |
| No transparent ghost copies | Pass | each pixel appears once |
| Static 390 px render reads as relief | Pass in my review; your judgment is the real gate | flutter/relief_390x844 vs original_390x844 |
| 45° render proves the geometry exists | Pass | *_side45 |
| Interaction not needed to perceive depth | Pass | camera frozen; drag test asserts identical pixels |

## Known limitations

1. **Mask detail.** Some edges are still approximate: the bottom pit rim (small jagged shadow bits), the Hades figure (fragmented), a few rear halos and the hand-drawn grey band. At phone size these are minor; up close they are visible.
2. **Coarse lower rock planes.** The broad lower facets on the left (`LF_*`) and the right wall are coarser than the crowns. Most of them sit under figures.
3. **Subtle production light.** At the 0.88–1.08 clamp, the facet contrast on pale rock is modest. The cast shadows carry more of the static read than facet shading does. The clamp is one constant in `tool/build_anastasis_v5.py` if you want more.
4. **Baked light.** The light is fixed and baked into `relief_front.jpg`. Re-enabling motion needs a Flutter mesh built from `build/height16.png`: the height field is ready, but that renderer is not written. It should come only after you accept this static pass.
5. **Test captures, not device measurements.** Rendering is a single texture draw, so performance risk is low. Two decoded 2048×1091 textures are resident, and the debug views decode only when selected. No device FPS was measured.
6. **Old bundles remain.** The archived v3 layered renderer is still reachable from the developer sheet, via the "Archived v3 layered renderer" switch, for on-device comparison. Its assets (`relief_v3/`, about 11 MB) and the older `relief/` stay bundled.

## Reproduce

```sh
python3.11 tool/build_anastasis_v5.py                   # labels, facets, height, shading (~15 s)
python3.11 tool/render_anastasis_v5_deliverables.py     # all images above + assets/anastasis/relief_v5 (~90 s)
flutter test --no-pub                                   # includes v5 asset/segmentation checks
flutter test --no-pub tool/mobile_relief_v5_screenshot_test.dart
```

The scripts need Python 3.11 with NumPy, OpenCV, SciPy, scikit-image and Pillow. Re-running SAM is optional: `SAM_CHECKPOINT=… python3.11 tool/anastasis_v5_sam_masks.py [ids]`.

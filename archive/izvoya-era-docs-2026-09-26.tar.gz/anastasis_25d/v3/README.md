# Anastasis relief, third-pass candidate

This is the current feature asset set for the Chora scene-detector Flutter app. It is integrated through the existing F02 detail and Anastasis tab routes. The production screen has one interactive relief, focus controls using that same scene, Original/Relief, touch inspection, pinch zoom, double-tap reset, and a hidden developer panel (long-press **ANASTASIS**). The two stacked static mountain crops from v2 were removed.

**Visual acceptance is incomplete.** The full stationary 390 × 844 render does not yet communicate four depth bands clearly enough. The masks, side-angle rendering, and rock light response are real and inspectable, but those are not substitutes for the required still-image result.

## V2 diagnosis

V2's two mountain masks each covered a whole side of the composition. `physical_relief.py` then subtracted rear people, leaving disconnected upper rock strips. Normalizing those fragments to a full height range produced high isolated peaks. Its hand-painted facet brightness factors of roughly 0.67–1.17 made yellow highlights and dark polygons. Side people had just one broad mask per side and nearly the same semantic depth. A complete source photo sat behind the planes, so centered meshes with identical RGB did not express semantic Z in a still image. Contact shadows were weak and often missed adjacent surfaces. The two large mobile crop widgets were additional static presentations, not better scene geometry.

All v2 assets remain archived under `assets/anastasis/relief/` and `anastasis_25d/mobile_v2/`; the app loads `assets/anastasis/relief_v3/manifest.json` instead. No source photographs or earlier diagnostics were modified.

| V2 layer | Mask and mesh | Z / local amplitude | Mobile finding and action |
| --- | --- | ---: | --- |
| mountain_left | `mountain_left_physical_mask.png`; subdivided photo mesh | .055 / .23 | Disconnected exposed strips, inflated facets; replaced by left back/mid/front |
| mountain_right | `mountain_right_physical_mask.png`; subdivided photo mesh | .055 / .25 | Same failure; replaced by right back/mid/front |
| figures_left_rear | `figures_left_rear_physical_mask.png`; photo mesh | .105 / .022 | Crowds fused; replaced by three left groups |
| figures_right_rear | `figures_right_rear_physical_mask.png`; photo mesh | .110 / .022 | Crowds fused; replaced by three right groups |
| tomb_left | `tomb_left_physical_mask.png`; photo mesh | .140 / .018 | Retained silhouette, lowered local relief |
| tomb_right | `tomb_right_physical_mask.png`; photo mesh | .145 / .018 | Retained silhouette, lowered local relief |
| lower_gates | `lower_gates_physical_mask.png`; photo mesh | .160 / .018 | Retained silhouette, lowered local relief |
| mandorla | `mandorla_physical_mask.png`; photo mesh | .205 / .025 | Retained silhouette, moved behind principal figures |
| adam | `adam_physical_mask.png`; photo mesh | .275 / .065 | Mask included pale terrain; tighter manual contour, still needs retouch |
| eve | `eve_physical_mask.png`; photo mesh | .290 / .065 | Retained source silhouette, shallower local height |
| christ | `christ_physical_mask.png`; photo mesh | .365 / .082 | Foreground effect worth retaining; silhouette and ranking preserved |

All v2 objects were alpha-textured Flutter `Canvas.drawVertices` grids in painter order, with normals derived from v2 height textures and lit PNGs. There is no Three.js renderer or hardware Z buffer in this repository. V3 likewise uses ordered textured geometry; alpha and painter order implement occlusion. This architectural limit matters when judging very tight intersections.

## V3 segmentation and depth

The [full color mask review](02_segmentation_masks_full.png) and [phone-sized version](02_segmentation_masks.png) show 19 independently configurable regions. The masks are 8-bit lossless PNGs in `assets/anastasis/relief_v3/`. Rock and group extents are manually authored in `tool/build_anastasis_v3.py` in 2048 × 1091 master coordinates. Group contours receive mask-constrained GrabCut cleanup. Christ, Eve, mandorla, tombs and gates reuse the best v2 silhouettes. Adam's perimeter was tightened manually. These are editable masks, not rectangular sprites; some group and Adam edges still need hand retouching.

Positive Z approaches the camera. Exact defaults in normalized artistic units:

| Component | Z | Local amplitude |
| --- | ---: | ---: |
| left/right rock back | .075 / .077 | .018 |
| left/right rock mid | .112 / .114 | .018 |
| left/right front ridge | .153 / .155 | .020 |
| left/right rear people | .190 / .192 | .006 |
| left/right middle people | .232 / .234 | .008 |
| left/right front people | .280 / .282 | .010 |
| left/right tombs, gates | .240 / .241 / .245 | .003 |
| mandorla | .308 | .004 |
| Adam / Eve | .352 / .354 | .013 |
| Christ | .438 | .018 |

The dark source field remains Z 0. The 19 rows and asset paths are machine readable in [layer_manifest.json](layer_manifest.json). Source photo selection and registration attempts remain in [the original audit](../source_audit.csv) and [registration diagnostics](../registration/). The 17:18:48 frontal image, prepared as `assets/anastasis/conch_reference.jpg`, remains the only visible RGB source. Other source photographs only informed geometry and color judgments; there is no blended or generated fresco imagery.

## Mountain construction and material

Each rock side has a back mass, middle plane, and front ridge. These masks follow the broad painted areas rather than an automatic luminance map. The local height in each plane is a smooth signed tilt plus a narrow bevel only where a named lower surface supports that edge. Its [left](04_left_mountain_heightmap.png) and [right](05_right_mountain_heightmap.png) maps are simple and fixed-scale. RGB brightness, cracks, pigment noise, and the old v2 AI/brightness facets do not feed geometry. Normals are Sobel derivatives of those maps, then normalized and saved; [normal debug](07_normal_debug.png) exposes them.

The app draws tight alpha-cropped grids: 13 master pixels between rock vertices, 19 for Christ/Adam/Eve, 30 elsewhere (about 7,035 vertices and 12,660 triangles at default quality). A controlled light vector modulates original RGB with a matte multiplier. No specular, metalness, bloom, generated texture, or generic volumetric people are used. Rock back/mid/front have distinct bases of .87/.955/1.02 before the clean normal response, clamped to .83–1; figure rear/mid/front bases are .91/.96/1, clamped to .90–1. The lit texture has only 1.015 headroom. Default raking angle is −20°. Narrow contact maps darken only overlaps with named lower layers. The source pixels dominate the appearance; the full-resolution diagnostic composite differs from the source by about 1.5 RGB levels per channel averaged over the entire panel.

The photo projector keeps source pixel alignment at the centered camera. A trial static perspective expansion exposed the original under shifted ridge masks and created a conspicuous double edge along the apse arch, so it was reverted. No missing hidden fresco area was fabricated. This is the main reason the centered screen remains weaker than the side and light inspection views.

## Interface, controls, and performance

The production entry is Scan/Scenes → F02 Anastasis → Explore painted relief. **Overview** uses a close phone framing; **Whole**, **Figures**, **Left rock**, and **Right rock** move the *same* relief view to the selected source window. One finger inspects within about ±5°/±3°, two fingers pinch to 3×, release eases back over 650 ms, double tap resets. There is no looping motion. Original/Relief comparison always uses the same framing. The public UI has no numeric controls.

Long-press the title for per-layer Z, visibility, relief and opacity; global relief, light angle, raking-light inspection, AO, contact, FOV, mesh quality, and masks/colors/semantic/local/combined depth/normals/wireframe/AO/shadow/side-angle developer modes. `sideAngle` rotates the photo plane 55° in the developer projection and spreads layers according to their actual Z. [Cross section](16_cross_section_debug.png) shows the numeric stack. The hidden debug mode does not imply a surveyed 3D apse.

At 390 × 844, 20 alternating software widget poses took **4.8 ms per build/paint frame** locally. This is not phone GPU FPS; no iOS or Android device was connected. `assets/anastasis/relief_v3/` is about 11 MB compressed; decoded memory is higher. Assets load when the feature opens and `ui.Image` resources are disposed when it closes. Only one viewer remains mounted, replacing three in v2.

## Rebuild and inspect

```sh
python3.11 tool/build_anastasis_v3.py --masks-only
# Review 02_segmentation_masks_full.png before accepting geometry changes.
python3.11 tool/build_anastasis_v3.py
flutter analyze --no-pub
flutter test --no-pub
flutter test tool/mobile_relief_screenshot_test.dart --no-pub
python3.11 tool/render_anastasis_v3_diagnostics.py
flutter run
```

Python requires NumPy, OpenCV and Pillow. The Flutter screenshot test produces the real widget stills at 360 × 800, 390 × 844 and 430 × 932, neutral and ±5°/±3° viewpoints, two rock focuses, raking light and side-angle view. Test fonts render as block glyphs in this environment; the painting and layout come from the real widget painter. `render_anastasis_v3_diagnostics.py` makes the source-aligned high-resolution comparison sheets and cross section. The full-resolution sheet is a diagnostic approximation of the same matte compositing, not a phone capture. The 18 numbered outputs requested for review are in this directory.

## Acceptance review (current candidate)

| Gate | Result | Evidence |
| --- | --- | --- |
| A — separate color masks | **Pass, with rough edges** | [02](02_segmentation_masks_full.png) has Christ, Adam, Eve, six people bands, six rock planes, background |
| B — four obvious levels in centered phone still | **Fail** | [08](08_static_relief_mobile.png) remains too close to a lit photograph |
| C — rock ridge/slope/rear plane in the still | **Fail at whole view; improved when focused** | [10](10_left_mountain_closeup.png), [11](11_right_mountain_closeup.png) remove v2 inflation but relief is still subtle |
| D — independent rock response to opposed raking light | **Pass in the debug close view** | [17](17_raking_light_left.png), [18](18_raking_light_right.png); full-resolution rock pixels differ about 9.8 RGB levels on average |
| E — Adam/Eve and front/rear crowds visibly occlude | **Fail in the whole still** | [12](12_figures_left_closeup.png), [13](13_figures_right_closeup.png) show better masks, insufficient spatial separation |
| F — preserve source RGB appearance | **Pass** | [09](09_original_vs_relief.png) and [pixel metrics](pixel_metrics.json); no yellow/white wash |
| G — physical Z stack in side view | **Pass for the current ordered mesh model** | [15](15_side_angle_debug.png), [16](16_cross_section_debug.png) |

### Next changes ranked by likely visual impact

1. Retouch Adam, Eve and six group contours against the source at high magnification. Several current group masks include pale ground and cannot give clean occlusion.
2. Replace the duplicated full-photo backing beneath raised forms with a **very narrow, explicitly documented** edge continuation limited to the default view envelope. This would permit a few pixels of actual static perspective separation without ghosting. Do not fill large hidden interiors.
3. Refine the rock front-ridge masks against painted plane joins, then tune a stronger local bevel only on supported overlaps. The current clean three-plane maps are preferable to v2 but still too broad to feel carved at 390 px.
4. Measure frame raster time and decoded image memory on a midrange iPhone and Android phone, then adjust mesh step or texture quality only if needed.

The current result is a working third-pass prototype, **not a visually accepted final relief**. The central still and figure occlusion gates remain open.

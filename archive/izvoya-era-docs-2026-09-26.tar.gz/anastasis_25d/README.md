# Anastasis painted relief — archived mobile second pass

The app now loads the [third-pass candidate and its honest visual-gate review](v3/README.md). This document records the earlier v2 implementation and screenshots only.

## What changed from v1

The original photo-aligned eleven-layer Flutter viewer remains the base. V2 gives each mountain a cleaned, coherent height field with hand-placed ridge spines and broad painted rock facets. Principal figures have shallower silhouette/fold relief. Normals from those fields drive matte upper-left raking light, short self-occlusion, and soft contact shading. The visible RGB is always the chosen source photograph multiplied by reversible display lighting; faces and garments were not generated or repainted. The layer order remains in [layer_manifest.json](layer_manifest.json).

The public flow is now **Scan or Scenes → F02 detail → Explore painted relief**, or the Anastasis tab's Explore action. It opens a dedicated phone viewer with the complete painting, two enlarged rock views, an Original/Relief switch, touch inspection, and reset. A long press on the viewer title opens developer controls. The old technical tab remains available only by long-pressing the Anastasis tab title. There is no Three.js or Gaussian-splat scene in this repository; this application renders through Flutter `Canvas.drawVertices`.

## Sources, registration, and historical boundary

The first-pass [source audit](source_audit.csv) covers all 24 files in the supplied Anastasis capture folder. The [contact sheet](source_contact_sheet.jpg) and [registration diagnostics](registration/) show the source choice and attempted ORB/homography alignment. The 17:18:48 frontal screenshot is the sole visible pixel source, prepared as `assets/anastasis/conch_reference.jpg` (2048×1091). The 17:18:16 capture is a geometry/coverage reference; `web-ke-01-CAN09421.jpg` is a contrast reference. Differently exposed viewpoints were never averaged or casually composited. Original files in the external capture folder are untouched.

No hidden paint, figure backs, anatomy, or rock texture was invented. The scene's dark field and apse border remain the source image. Large unseen regions exposed during extreme motion remain a known limit; the default ±5° horizontal and ±3° vertical range is conservative.

## Assets and geometry

`tool/build_anastasis_relief.py` retains editable polygon silhouettes and conservative GrabCut cleanup for Christ and Eve. Its crops have 24 pixels of margin for short contact shadows. `tool/physical_relief.py` reads those masks, excludes rear-figure overlap from the mountain physical mask, and writes:

- `*_height.png`: normalized local displacement; `*_height_viz.png` and `*_combined_viz.png`: alpha-masked debug views.
- `*_normal.png`: normals calculated from cleaned height, never pigment texture.
- `*_lit.png`: original RGB with matte raking-light display response.
- `*_ao.png`, `*_ao_overlay.png`: self-occlusion diagnostic and tunable overlay.
- `*_shadow.png`: short soft contact boundary, especially at figure and rock overlaps.
- `*_physical_mask.png`: the exact area receiving the physical lighting treatment.

Raw and cleaned intermediate maps are in [physical](physical/). The mountain ridge/facet control points live in `tool/physical_relief.py` as master-image pixel coordinates. These are manual depth interpretations of the visible painting. Facets are deliberately broad enough to survive reduction to a 390 px phone view; their angular boundaries are the main remaining subjective choice.

Semantic depth is positive toward the viewer: background 0, mountains .055, rear groups .105–.11, tomb/gates .14–.16, mandorla .205, Adam .275, Eve .29, Christ .365. Local physical amplitudes are .23/.25 for mountains, .065 for Adam/Eve, .082 for Christ, and .022 or less for rear groups. Runtime depth is semantic offset plus local height times `reliefScale` (default 1.5); these values are artistic, not meters. The photo projector keeps every master pixel aligned at the neutral view. It uses adaptive grids: 17 master pixels for mountains, 24 for principal figures, 42 for other layers. At default quality there are about **6,365 vertices and 11,818 triangles per viewer**. The three visible views render about 19k vertices. The generated relief directory is about **15.9 MB compressed**; decoded GPU/CPU image memory is larger.

The optional `ConchSurface` projection from v1 remains in hidden developer controls. Its apse curvature is a mathematical approximation and visibly distorts the composition, so the photo-aligned relief is the public default.

The [relief strength comparison](mobile_v2/relief_scale_comparison.jpg) tests 0.75, 1.0, 1.25, 1.5, and 2.0 on a 390 px software render. The 1.5 setting is the first that makes both mountain crowns reliably legible at rest without the harder facet shadows seen at 2.0.

## Mobile interaction and debugging

Touch drag inspects the view within ±5°/±3°, then eases back over 650 ms. The two rock detail views follow at half the movement. There is no character sway or looping presentation motion. A double tap on the main painting, or the reset button, returns to center. The stationary view already uses the default raking light and AO; motion is supplementary.

Long-press **ANASTASIS** inside the viewer for presets, layer visibility/depth/local relief, light angle/intensity, ambient, AO, contact shadow, parallax, FOV, and mesh quality. Modes include RGB, masks, layer colors, semantic/local/combined depth, normals, wireframe, AO, shadows, and edges. `FLAT_ORIGINAL`, `SUBTLE_RELIEF`, `BALANCED`, `STRONG_DEPTH`, and `DEBUG_EXAGGERATED` remain. The normal/height/lighting assets are generated files, so some parameters affect runtime modulation around a fixed baked reference. Device DPR is managed by Flutter and was not exposed as a public control.

## Reproduce and inspect

```sh
python3.11 tool/build_anastasis_relief.py
python3.11 tool/physical_relief.py
python3.11 tool/render_mobile_relief.py
flutter analyze --no-pub
flutter test --no-pub
flutter test --no-pub tool/mobile_relief_screenshot_test.dart
flutter run
```

The Python scripts require NumPy, OpenCV, and Pillow. Run the physical script after the base mask builder: the base builder regenerates editable masks and original layer crops, and the physical script then adds v2 depth/lighting assets and manifest entries.

[Mobile v2 diagnostics](mobile_v2/) include software composites and five original/v1/v2 close-up sheets (Christ/mandorla, Adam/left crowd, Eve/right crowd, both mountains). [Flutter captures](mobile_v2/flutter/) are real widget renders at 360×800, 390×844, and 430×932, plus neutral/left/right/up/down and original at 390×844. The test environment substitutes block glyphs for some fonts; artwork pixels and layout come from the Flutter painter. Center screenshots have zero animation and neutral camera. The software composites are labeled separately and do not stand in for app captures.

At 390×844, 20 alternating poses took **6.3 ms per widget build/paint frame** in the local Flutter software widget test. This excludes physical phone GPU raster/composition and is **not** a measured device FPS. No phone or emulator was connected. The app loads the relief when opened and disposes decoded images when closed. Three simultaneous views and decoded PNG textures remain the primary mobile memory risk.

## Visual assessment and next improvements

The centered screenshots show a clear raised top ridge and facets on both mountains; the source painting remains recognizable. The mountain detail views make physical relief legible without movement. Christ remains nearest, Adam/Eve occupy a separate band, and rear groups recede. The major limits are:

1. **Mask boundary refinement:** Adam's wrist, Christ's robe edge, and crowded heads still deserve hand retouching. This will improve depth credibility most.
2. **Mountain facet review:** the manually traced right ridge can look angular at close range. More control points and smoother transitions would make it feel more like carved plaster.
3. **Phone GPU validation:** measure raster time, peak texture memory, and touch smoothness on actual midrange iOS/Android devices; only software timings are available here.
4. **Disocclusion:** narrow duplicate fresco pixels can appear at the ±5° limit. Tightening per-layer masks or reducing the range will be safer than fabricating hidden paint.
5. **Color/exposure:** the master photo has clipped highlights along the lower fresco; no display adjustment can restore information absent from that capture.

No claims are made that the relief is surveyed apse geometry or a literal reconstruction of the original plaster surface.

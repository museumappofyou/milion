# Anastasis shallow relief prototype

## What is in the app

The Anastasis tab now defaults to a photo-aligned layered relief. The center
view places every layer exactly over its pixel in the frontal master capture.
Dragging is limited to about ±11° horizontally and ±7° vertically. The
background remains in place while semantic layers shift by their configured
depth; a low-frequency height field slightly varies each layer's movement.
Christ is the foremost layer and has a very restrained edge and display
adjustment. No figure, face, garment, or hidden region is generated.

The previous mathematical conch projection remains available through
**Relief controls → Architectural conch projection**. It illustrates the apse
curvature but strongly compresses parts of the painted composition, so it is
experimental rather than the default. There is no measured apse mesh or
Gaussian-splat asset in this Flutter repository.

## Sources and image choice

All 24 image files in the supplied `C__F02__Anastasis__dome__REF-8` folder
were inspected. [source_audit.csv](source_audit.csv) records resolution,
visible portion, coverage, obstruction, sharpness proxy, and role for each;
[source_contact_sheet.jpg](source_contact_sheet.jpg) shows them together.

The 17:18:48 frontal screenshot is the sole source of painted pixels in the
relief. Its prepared copy is `assets/anastasis/conch_reference.jpg` (2048 ×
1091); the original in the external capture folder was left untouched. It
covers Christ, Adam, Eve, both rear groups, terrain, gates, and the full arch.
Its lower edge is bright and partly clipped. The 17:18:16 view has useful
coverage but a different crop/viewpoint. `web-ke-01-CAN09421.jpg` has stronger
contrast but perspective, exposure, restoration/processing differences and a
watermark; it is a color and geometry reference only. The 2014 images establish
the painting's semi-dome context. Detail captures inform boundary decisions.
No source photographs were averaged or composited into the master.

## Registration

OpenCV ORB matching and RANSAC homography were attempted for the prepared
17:18:16 and flat reference images against the master. Match counts,
homographies, aligned previews, and 50/50 overlays are in
[registration](registration/). The alternate capture yielded 1244 inliers from
1271 ratio-filtered matches, sufficient to compare shared painted features.
The flat photograph yielded 352 inliers from 1091 filtered matches; its more
different projection and illumination make a single homography unsuitable for
pixel-level fusion. The diagnostics are for inspection only: they do not warp
the master or feed generated pixels into the layers. No lens coefficients or
physical control points were available for reliable lens calibration.

## Masks and depth

[layer_manifest.json](layer_manifest.json) lists eleven layers in back-to-front
order: left and right mountains, left and right rear groups, the two tombs,
lower gates, mandorla, Adam, Eve, and Christ. Dark field and surrounding apse
are the original base image at zero depth. The saved masks are 8-bit PNGs in
`assets/anastasis/relief/`; their editable polygon points are in
`tool/build_anastasis_relief.py`. Polygons were traced on the actual master.
Constrained OpenCV GrabCut refines Christ and Eve; its result is clipped to the
hand-traced outer silhouette. GrabCut was rejected for Adam after an inspected
trial pulled pale terrain into his robe. Erosion and a two-pixel alpha falloff
keep uncertain edges conservative. No pretrained segmenter was used. The
current silhouettes are serviceable for a first relief but are not
pixel-perfect, especially in the rear groups and touching hands.

Depth values in the manifest are normalized artistic order, positive toward
the viewer, not meters. Defaults: mountains 0.055, rear groups around 0.11,
tombs/gates 0.14–0.16, mandorla 0.205, Adam 0.275, Eve 0.290, Christ 0.365.
The default global scale is 0.25. Heights derive from a blurred LAB lightness
field plus distance from each silhouette and are multiplied by each layer's
small `reliefStrength`; semantic depth always dominates. This yields shallow
surface variation without interpreting robe folds as full human anatomy.
RGBA layer crops copy original RGB pixels and attach the editable alpha mask.

## Rendering and controls

Flutter `Canvas.drawVertices` draws small subdivided meshes for each cropped
layer over the original photograph. The source/crop coordinate system is
master pixels with (0, 0) at top left. The photo projector preserves exact
source positions at center. Movement changes only the layer offsets, with a
minor side-curvature term for the apse. Crops are used to reduce transparent
overdraw; the relief assets total about 5.7 MB compressed. Height maps and edge
textures load with the layer textures. The older conch surface is an optional
architecture context projection using `ConchSurface`.

Open **Relief controls** below the viewer. Presets: `FLAT_ORIGINAL`,
`SUBTLE_RELIEF`, `BALANCED` (default), `STRONG_DEPTH`, `DEBUG_EXAGGERATED`.
You can adjust global depth/relief, parallax and angle limits, lighting,
saturation/contrast/brightness, edge softness, Christ's focal adjustment,
per-layer depth/relief/visibility/opacity, and solo a layer. Modes show layer
colors, depth bands, masks, wireframe, and edge outlines. The edge-softening
slider affects the subtle separation edge; mask alpha falloff is regenerated
by the asset script. Lighting only modulates a few percent of texture value.
No AO, bloom, cast shadows, normal map, or generative 3D model is used.

## Rebuild and launch

```sh
/opt/homebrew/bin/python3.11 tool/build_anastasis_relief.py
/opt/homebrew/bin/python3.11 tool/render_anastasis_relief.py
flutter analyze
flutter test test/anastasis_tab_test.dart test/anastasis_manifest_test.dart
flutter test tool/anastasis_screenshot_test.dart
flutter run
```

The Python environment needs Pillow, NumPy, and OpenCV. The first command
reads the supplied external folder for the audit and reads the prepared master
in this repository for generated assets. The second command produces the five
reproducible viewpoint diagnostics and mask/depth views in
[screenshots](screenshots/). `center.png` and `*_diagnostic.png` are fast OpenCV
composites matching the projector's layer order and approximate displacement.
They do not include the Flutter widget chrome or its subtle display filter.
The Flutter screenshot tool writes the full app UI to
`build/anastasis-preview/ui-*.png`; `app_context.png` is a copy of its top
viewport.

## What still looks wrong, in order of visual impact

1. **Silhouette precision.** Christ's robe/hand and the Adam/Eve wrist joins
   need close manual contour refinement. Rear groups currently use broad
   group boundaries. Correcting these will have the largest visual benefit.
2. **Disocclusion.** At the edge of the viewing envelope, the untouched base
   photo can show a narrow duplicate strip behind a shifted layer. It is
   intentionally left as original material instead of inventing hidden paint.
   Smaller parallax or locally refined edge margins will reduce it.
3. **Exposure.** The master's lower register is bright. Display controls are
   reversible but cannot recover clipped photographic highlights. A measured,
   carefully color-matched future master could help if rights and alignment
   permit.
4. **Apse geometry.** The existing conch model is an artistic approximation
   and visibly distorts the picture. A surveyed apse surface with calibrated
   photo projection is needed before using the curved mapping as default.
5. **Mobile memory.** Eleven RGBA crops plus debug edge images decode into
   more memory than their ~5.7 MB compressed total. Lazy-loading edge assets
   and building an atlas are the next performance changes.

The key uncertainty is unobserved paint behind foreground figures. The
prototype deliberately does not synthesize it; viewpoint limits and shallow
depth keep that uncertainty small.

# chora_scene_finder

A small Flutter companion for the Chora/Kariye scene recognizer: scan a scene
with the camera (on-device ONNX classifier), browse the catalog, and read and
write notes per scene.

## Front page and theme

The app now opens on a fresco-led home page with direct access to both interactive
scenes, source photographs, the collection and scanner. A warm ivory, forest-green
and gold theme brings the navigation, scene controls and restoration views together.
The catalog adds room and Interactive filters; the recognition model loads only
when Scan is selected. See [screenshots and UI notes](ui_refresh/README.md).

## Anastasis painted relief

Scene F02 (the Anastasis in the Parekklesion) opens a dedicated mobile painted
relief viewer from a scan result, the Scenes catalog, or the Anastasis tab.
The explorer adds 1×–8× pinch/button zoom, pan, tappable details, animated focus
transitions and articulated figure animation: heads turn, hands reach and robes
move. Animate/Pause figures, Still and a pose slider work with every image view.
See [figure animation and previews](figure_animation/README.md).
Original/Relief/Restored comparison keeps source images available; restoration
studies are separate files with an adjustable blend. Scene options contains
the unchanged Classic v5 viewer and its diagnostics.
See [the fifth-pass geometry, gates and limitations](anastasis_25d/v5/README.md).

- V5 relief: `tool/build_anastasis_v5.py` (height field and shading),
  `tool/render_anastasis_v5_deliverables.py` (diagnostics and
  `assets/anastasis/relief_v5/`), loaded by
  `lib/services/anastasis_relief_v5.dart`.
- Archived v3 relief and geometry: `lib/services/anastasis_relief.dart` and
  `lib/services/conch_geometry.dart`.
- Viewer: `lib/widgets/anastasis_dome_view.dart` (subdivided layers drawn with
  `Canvas.drawVertices`).
- Entry and mobile screen: `lib/screens/anastasis_tab.dart` and
  `lib/screens/anastasis_relief_screen.dart`.
- Assets and manifest: `assets/anastasis/`, prepared by
  `dart run tool/prepare_anastasis_assets.dart` from the capture folder
  `chora-ar/captures/chora-scenes/5-PAREKKLESION/C__F02__Anastasis__dome__REF-8`.
  The tool trims the capture viewer's letterbox bars, crops its
  picture-in-picture overlay where present, and records every source, credit
  and derivative in `assets/anastasis/captures.json`.
- Mobile captures: `flutter test tool/mobile_relief_v5_screenshot_test.dart`
  writes real widget renders to `anastasis_25d/v5/flutter/`.

The relief is a single-view interpretation of pictorial depth, not a measured
survey or a photogrammetric mesh. The default center view preserves the source
photograph's positions and artwork.

## Last Judgment painted relief

Scene F05 has a **Judgment** tab and shares the same interactive explorer as
Anastasis. Open it directly or choose **Explore painted relief** from its catalog
entry or scan result. Examine the Deesis, Christ, apostles, heavens, throne and
river of fire. The original static viewer and 45° diagnostic remain available
under **Scene options → Classic v5 viewer**.

The supplied full-vault photograph drives one continuous surface with 77
authored parts; close reference photographs are also available in the tab.
See [Last Judgment sources, construction and reproduction](last_judgment_25d/v5/README.md).

## Interactive exploration and restoration studies

See [controls, restoration prompts, preserved originals and screenshots](restoration_studies/README.md).
The Restored view opens at 100% with new, separate 3840-pixel-wide restorations
for both scenes. The original four studies remain available. These 4K exports
are upscaled from AI-generated restorations; reconstructed details are interpretive.
See [4K files and generation notes](restoration_studies/v2/README.md).
Figure playback uses a six-second loop with adjustable movement strength,
defaulting to Bold. See [the stronger v2 animation](figure_animation/v2/README.md).

## Getting Started

- [Learn Flutter](https://docs.flutter.dev/get-started/learn-flutter)
- [Flutter documentation](https://docs.flutter.dev/)

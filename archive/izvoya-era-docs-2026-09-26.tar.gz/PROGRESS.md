# İzvoya — progress and Android readiness

Audit date: **2026-09-26**. Current bounded-release readiness: **19.9%** (equal-weight mean across 46 dimensions). **Not ready to ship.** P00 is complete; P01–P35 have not been implemented in this run. The roadmap itself earns no feature-completion credit.

Read `PHASES.md` for scope, phase prompts, budgets, external issues and official reference anchors. This file records evidence and remaining gaps only. Scope is the expanded Istanbul Android product, not the previous two-scene Chora prototype. Scores are an evidence-based engineering assessment, not a percentage of code coverage, work-hours completed or predicted commercial success.

## Scoring and ship rule

| Score | Meaning |
| --- | --- |
| 0% | No relevant implemented capability/evidence. A written plan does not count. |
| 10% | An artifact, claim or limited starting point exists; usable scope not established. |
| 25% | A narrow prototype/subset works; major agreed scope or validation is missing. |
| 50% | Substantial functionality exists with local automated/visual checks; important scope/device/user gaps remain. |
| 75% | Agreed implementation and local validation substantially complete; specific field, human or operational gates remain. |
| 90% | Release-candidate evidence satisfies nearly all criteria; a named final gate remains. |
| 100% | Every row-specific acceptance gate and applicable shared release gate passed on the current candidate, with evidence and an accountable owner. |

Use these milestones rather than invented precision for individual rows. Do not promote a whole dimension because one of its phases finishes. Scores may decrease when regression, stale evidence or scope expansion exposes a gap. For content counts, also report actual reviewed/required counts; number of draft records alone cannot yield 100%. No dimension becomes N/A silently; explicit scope decisions must update both files and the denominator before rescoring.

**Ship-ready means every dimension is 100%, the current candidate passes the PHASES.md acceptance contract, and every release-blocking external issue is resolved or eliminated by an explicit scope decision.** An average is only a progress indicator; strength in branding cannot compensate for broken data or unvalidated recognition. Meeting this rule means the bounded Android release is ready for an owner publication decision, not that this task may automatically publish it or that user acquisition is guaranteed.

## Current app: what the audit actually found

- **Content:** 103 Chora classes, 103 mapping records and 103 summaries; one monument represented. Two hardcoded interactive scenes: Anastasis F02 and Last Judgment F05. No city place catalogue, districts, museum-object model, map or itineraries. Room position text is not geographic coverage.
- **Experience:** working scene browsing/search/room and Interactive filters; on-device live/still/gallery recognition; local scene notes; original/relief/restored comparisons; 1×–8× zoom, detail focus, manual pose and figure playback. Catalog browsing does not initialize ONNX. The clean identity is new; the wider UI redesign remains planned.
- **2.5D:** real authored depth/shading assets plus surface-deformation rigs. V2 reports 54,891/62,220 vertices, 21,200/20,185 animated vertices, 48 poses over 6 seconds, and about 15.9 MB combined pose data. Positive-area and lifetime regression checks pass. The visual format is promising, but authoring remains two-scene-specific and there is no measured physical-device budget.
- **True 3D:** development PLY/height-field artifacts exist; the Android experience is not a freely explorable measured 3D space. There is no installed runtime 3D content-delivery architecture. Do not count PLY exports as six completed 3D exhibits.
- **Visual review:** inspected current home at phone widths/150% text, viewer close-ups and six sampled frames of each existing Anastasis/angel preview. The original-to-relief comparison and specific hand/wing gestures are useful focal moments. Dense pose/strength/variant controls take substantial screen space; bold deformations can change nearby outlines and deserve close review. The generic headline delays artwork, especially with larger text. These are expert review observations, not study findings or a complete frame-by-frame/device motion audit.
- **Historical accuracy:** original textures are preserved; restored 4K exports are upscaled interpretive reconstructions, not newly recovered source detail. Current About text lists model performance numbers without a reproduced evaluation dataset in this run. It also admits weak negative rejection. Those claims receive no new validation credit.
- **Android:** Flutter 3.47.2 / Dart 3.13.2; current APK minimum API 24, target/compile API 36. PHASES.md proposes a more deliberate tested floor of API 29; that support decision has not been implemented. Release Gradle configuration still uses debug signing. Build warns that `flutter_onnxruntime` applies the older Kotlin Gradle Plugin; review compatibility in P32 before upgrading Flutter.
- **Merged permissions:** inspected APK declares CAMERA, RECORD_AUDIO, READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE (through API 28), ACCESS_NETWORK_STATE and the app's non-exported receiver permission. Source manifest alone understates dependency-added permissions. P27 must justify/remove unnecessary permissions and verify actual runtime/network behavior.
- **Scale/cost:** source asset folders total approximately 89 MB on disk (filesystem `du`, rounded); universal APK is 203,764,842 bytes. This is not an estimated Play device-specific delivery size. Old relief generations remain bundled. No CDN/download cache, service account, analytics, audio, sharing, personalization or bilingual UI.
- **Project state:** no Git repository found at audit time. Existing authoring tools include external `/Users/memre/Desktop/chora-ar/...` source defaults; these are genuine source-corpus references, not app branding. Clean-checkout authoring must be repaired in P01/P06. Historical READMEs describe earlier passes and are not current completion claims.

## Identity and path changes in this run

| Surface | Current result |
| --- | --- |
| Display identity | **İzvoya** — “Istanbul, layer by layer”; coined from the idea of a trace/exploration. No claim of globally cleared uniqueness. |
| App/package namespace | `IzvoyaApp`, Dart package `izvoya`, Android `com.izvoya.istanbul`. |
| Theme and native paths | `lib/theme/izvoya_theme.dart`; `android/app/src/main/kotlin/com/izvoya/istanbul/MainActivity.kt`; `izvoya.iml` / `android/izvoya_android.iml`. |
| Logo system | Code-authored tessera/water mark; `assets/brand/izvoya-mark.svg`, `assets/brand/izvoya-icon.png`, Flutter painter, five launcher densities, adaptive/themed icon and Android splash. Rebuild with `python3.11 tool/build_izvoya_identity.py` (Pillow). |
| Existing preview identity | `web/izvoya-mark.svg`, names/icons aligned; no new web/iOS product work. |
| Workspace | Renamed to `/Users/memre/Desktop/izvoya`; relocation validated with E07. |
| Preserved place/model identity | Historical Chora names, source corpus paths, F02/F05, original notes keys and `assets/model/chora_scene_classifier.onnx` retained intentionally. |

The new Android application ID installs as a separate app. It cannot silently access notes in the old `com.chora.chora_scene_finder` sandbox. No uninstall/overwrite/data migration on a user device was performed. P01/P27 include explicit legacy export/import support. A temporary pre-rebrand source backup and original hash list were stored under `/tmp/izvoya-audit/`; that is a session safeguard, not durable version control.

## Dimension scorecard

The final column identifies implementation owners by phase; the specific missing work is the gap between “current evidence” and “100% acceptance”. External dependencies are tracked only in PHASES.md's O01–O09 table.

| ID | Dimension | Current | Current evidence / limit | Required for 100% | Phases |
| --- | --- | ---: | --- | --- | --- |
| D01 | Product scope and positioning | 25% | The contract/targets now exist; audience value is untested. | Scope/offer accepted, P30 audience thresholds met, no misleading product promise. | P00/P30/P34 |
| D02 | Brand and identity consistency | 75% | New mark, wordmark, package, launcher/splash and metadata build; E02–E04. | Identity works on real launchers/themed icons, all release touchpoints and bilingual store assets; human distinctiveness review. | P00/P02/P30/P34 |
| D03 | Distinctive visual design | 50% | Existing coherent serif/sans theme and artwork hero; new mark. Screens still resemble a small editorial landing page. | All six compositions serve their content, pass layout/accessibility QA and identity/understanding study. | P02/P05/P30 |
| D04 | Navigation and continuity | 50% | Home/Collection/Scan/About and two explorer routes work; E02. | Discover/Atlas/Cabinet, correct back/state restoration and every error/retry path verified. | P03/P27 |
| D05 | First-use activation | 25% | Direct Anastasis entry and lazy scanner loading; no timed user evidence. | No-permission first reveal ≤30 s and ≥80% reveal/save/find-place task completion in P30. | P03/P24/P30 |
| D06 | City-scale domain architecture | 25% | Scene and ExplorableScene models; catalogue is tied to classifier classes and two static experiences. | Versioned places/artworks/routes/packs, independent repositories, scoped IDs and compatibility migrations pass. | P01/P04/P29 |
| D07 | Editorial trust and review | 25% | 103 summaries and source manifests exist; external scholarly/bilingual review not evidenced. | Every release claim/interpretation has appropriate source, review/date and uncertainty; reviewers named. | P04/P25/P29 |
| D08 | All-Istanbul geographic coverage | 0% | Only Chora is implemented; a planning queue does not count as content. | 39/39 districts contain reviewed meaningful content; ≥90 distinct reviewed places and automatic coverage audit. | P18 |
| D09 | Byzantine catalogue depth | 25% | 103 Chora scene records and two interactive works, all within one place; E01/E05. | ≥24 distinct reviewed Byzantine-related places; flagship Chora and wider-neighborhood chapters accepted. | P09–P11 |
| D10 | Mosque catalogue depth | 0% | No dedicated mosque architecture/craft catalogue; Chora current use alone does not satisfy this wave. | ≥24 reviewed mosque entries and differentiated, respectful architecture/craft stories across both shores. | P14/P15 |
| D11 | Museum/object catalogue depth | 0% | No institution/object inventory or museum-specific discovery flow. | ≥24 reviewed museum entries, stable object identities and display-state handling across institution types. | P16/P17 |
| D12 | Visit information and freshness | 10% | Chora room/position strings exist; no live-place access schema. | Every release place has dated entrance/access data or explicit unknown, closure alternatives and review ownership. | P04/P13–P18/P29/P33 |
| D13 | Atlas and location discovery | 0% | No map, district model, nearby permission flow or map/list equivalence. | Map/list/filter synchronization, manual/denied/offline paths and correct entrances pass field checks. | P12/P33 |
| D14 | Routes and visit planning | 0% | No route model, editor or field evidence. | 12 reviewed routes across both shores; honest distance/time/access, interruption and closed-stop recovery. | P13/P15/P17/P33 |
| D15 | Search and content findability | 25% | Scene title/room search, Interactive filter and clear-empty behavior; E02. | City/place/object/alias/diacritic search plus composable filters and 500-saved-item usability pass. | P12/P19/P25 |
| D16 | 2.5D collection quality | 50% | Two reliefs with originals/restorations and focus details; source and mesh tests pass. | 12 approved pieces with 6/3/3 wave split; phone/zoom visual review, comparisons, fallback and budget checks. | P05/P06/P09–P17/P30 |
| D17 | Motion craft and control | 50% | Two 48-pose rigs, six-second loops, pause/still/strength and reduced motion; E02/E05. | Each piece has a meaningful authored reveal, no unacceptable deformation, clear source state and user-validated restraint. | P05/P06/P30 |
| D18 | Genuine 3D experience quality | 0% | Offline relief meshes are development artifacts; no runtime spatial exhibit/3D engine. | 6 true 3D exhibits, 2 per wave, with coherent geometry, interpretation, meaningful interaction and device-proven fallback. | P07/P09–P17/P28/P30 |
| D19 | Asset production and versioning | 50% | Substantial deterministic scripts, masks/manifests and original hashes; machine-specific source defaults remain. | Manifest-led, reproducible multi-place pipeline, approved assets, schema/integrity checks and deterministic packs. | P01/P06/P08/P29/P32 |
| D20 | Performance and resource efficiency | 25% | Lazy ONNX, renderer cleanup tests; ~203.8 MB universal APK; no physical frame/memory data. | All agreed cold-start/frame/PSS/thermal/pack budgets measured on physical floor/mid/high devices. | P07/P08/P22/P28 |
| D21 | Offline and download resilience | 25% | Bundled catalogue/model/artwork/notes work locally; no optional pack system. | Small first-install starter plus verified/resumable packs, low-storage/corruption recovery and removal without data loss. | P08/P19/P28 |
| D22 | Personal cabinet and collecting | 25% | Per-scene local notes only; no saves/sets/visited/library model. | Persistent artwork/place/route cabinet, useful sets, notes, export/import and tested collection completion flow. | P19/P24 |
| D23 | Narrative and interpretation | 25% | Short scene summaries and six detail hotspots per interactive scene; no complete authored chapters. | 18 reviewed bilingual stories with specific takeaways, original/interpretation comprehension and coherent place connections. | P09–P20/P25/P30 |
| D24 | Audio and silent equivalence | 0% | No narration pipeline or audio player. | Reviewed TR/EN narration for the agreed stories, offline focus/interruption handling and equal caption/transcript experience. | P20 |
| D25 | Recognition functionality and UX | 50% | 103-class ONNX model, live/still/gallery input, thresholds and tentative top matches. | Camera/format/orientation/denial recovery works; explicit supported scope, manual fallback and no false certainty. | P21/P22/P33 |
| D26 | Recognition validity and calibration | 10% | About screen asserts past accuracy and weak negative rejection; no reproduced held-out evaluation here. | P21 positive/negative gates pass with session-separated data and per-class results; P22 expansion accepted or explicitly rejected. | P21/P22/P33 |
| D27 | Sharing and deep links | 0% | No export, Sharesheet or per-detail app-link implementation. | User-initiated still/clip export, cancellation, privacy and cold/warm/missing-pack return paths pass. | P23/P31 |
| D28 | Repeat value and recommendations | 0% | No personal recommendations, return loop or cohort evidence. | Transparent diverse suggestions, reset/opt-out and meaningful repeat-use reasons evidenced in study/pilot. | P19/P24/P30/P31 |
| D29 | Turkish/English completeness | 0% | Current interface and narrative strings are English; Turkish place names are not localization. | All release UI/content/semantics/exports reviewed in both languages; missing-key and switching tests pass. | P20/P25 |
| D30 | Accessibility | 25% | Some semantics, large-text layouts, motion-off and lifecycle tests exist; no TalkBack audit. | TalkBack/task equivalence, 200% text, target/contrast checks, captions and static/map-list alternatives verified. | P02/P05/P20/P26 |
| D31 | Android layouts and device coverage | 50% | 390/360 phone, tablet/desktop and 150% text widget captures; E02/E04. | Supported phone/tablet/foldable/landscape/200% text and system-bar/back behavior verified on agreed Android matrix. | P02/P03/P25/P26/P28 |
| D32 | Android lifecycle and permissions | 25% | Explorer pauses/disposes and camera has some error handling; process-death/device coverage absent. | Camera/audio/3D/export process lifecycle, permission revocation/no hardware, interruptions and state recovery pass. | P03/P07/P20/P21/P26–P28 |
| D33 | Privacy and permission minimization | 25% | Inference/notes are local and no account/analytics exists; merged APK includes microphone/storage permissions. | Measured network/permission inventory justified, local defaults, export/delete, consent and opt-out match actual behavior. | P12/P21/P23/P24/P27/P31 |
| D34 | Persistence and data migration | 25% | SharedPreferences scene notes; no versioned migration, pack/user isolation or recoverable import. | Notes/saves/visits/routes survive upgrade/interruption; import/export/delete and legacy-ID/package handoff validated. | P01/P08/P19/P27/P32 |
| D35 | Security and dependency health | 25% | Small dependency set and native asset cleanup; no input/update/security review or dependency gate. | Input/link/manifest validation, safe downloads/imports, no bundled secrets, reviewed dependencies and signing safeguards. | P08/P21/P27/P32/P35 |
| D36 | Automated regression coverage | 50% | 37 app tests plus 2 screen-capture tests passed now; E02. | Meaningful tests cover expanded release journeys, model/pack/data errors, lifecycle and corrected regressions. | P32/P33 |
| D37 | Reproducibility and continuous integration | 10% | Existing build scripts/tests work locally; workspace is not currently a Git repository, no CI. | Clean checkout builds from pinned inputs, validation gates run reproducibly and intentional regressions fail. | P01/P32 |
| D38 | Content publishing and freshness operations | 0% | Static bundled JSON and manual scripts only. | Owned draft/review/publish/archive workflow, freshness queue, content-only update and rollback demonstrated. | P04/P18/P29 |
| D39 | Product measurement | 0% | No defined implemented consent/event/funnel system; future targets are only a plan. | Opt-in event pipeline/dashboard computes honest activation/return/export funnels and honors deletion/opt-out. | P24/P31 |
| D40 | Audience desirability evidence | 0% | No research or repeat-use study provided; screenshot appeal is not user validation. | P30 cohort, task/comprehension/return thresholds met and consequential issues retested. | P30/P33 |
| D41 | In-city field validation | 0% | No physical route/access/scanning/device field evidence in this workspace. | All published routes and representative place/recognition journeys reviewed in real conditions; P33 pilot complete. | P13/P28/P33 |
| D42 | Offer and operating sustainability | 10% | Private prototype exists; no release pricing/cost/owner decision. | Owner-approved free/paid launch offer, measured service costs and billing/restore checks if payments are selected. | P34 |
| D43 | Android release engineering | 25% | New package release APK builds, but is debug-signed; E03. | Production-signed AAB, current platform/store checks, clean install/update, asset delivery and recovery verified. | P00/P32/P35 |
| D44 | Store and launch material | 0% | No reviewed listing, privacy form, launch screenshots or verified release preview. | Truthful bilingual store material accurately matches signed candidate and its actual data/permissions. | P34/P35 |
| D45 | Support and operational ownership | 0% | About/credits exist; no support contact, correction workflow, response owner or recovery cadence. | Owned support/correction process, in-app help, issue triage, source review and recovery rehearsal complete. | P29/P34/P35 |
| D46 | Acquisition and attraction experiments | 0% | No tested acquisition creatives/funnel; current art appeal is a hypothesis. | Three specific bilingual acquisition experiments prepared/evaluated with real exposure denominators and an owned launch plan. | P23/P31/P34/P35 |

## Validation evidence

“Current” means run or directly inspected on 2026-09-26 for this rebrand. Existing JSON reports are historical evidence only. Machine-readable assets/results may be stored beside code; human interpretation stays here.

| ID | Evidence | Result / limitation |
| --- | --- | --- |
| E01 | `assets/model/classes.json`, `class_map.json`, `assets/data/scene_info.json`; `lib/models/scene.dart`, `explorable_scene.dart` | Confirmed 103 records in each data file, two static interactive definitions. Model catalogue order is still the source of scene browsing. |
| E02 | `flutter test --no-pub test tool/frontier_screenshot_test.dart` | **39 passed**: 37 app tests + 2 visual-capture tests; includes scene navigation, geometry, assets, figure lifetime, zoom, comparison and motion-off behavior. These are not 39 device tests. |
| E03 | `flutter build apk --release --no-pub`; Android SDK `aapt dump badging` | **Passed**; APK `build/app/outputs/flutter-apk/app-release.apk`, 203,764,842 bytes, package `com.izvoya.istanbul`, label İzvoya, version 1.0.0+1, min 24/target 36. Debug signing remains. SHA-256 `df76dbdafd145200a961c4b918a8695f5f821130bca8cfa2fa0b2f84bd6914af`. |
| E04 | `flutter analyze --no-pub`; rendered `ui_refresh/previews/home_360x800.png`, `home_390x844.png`, `home_large_text.png`; `assets/brand/izvoya-icon.png` | **No analyzer issues** after rename. Generated phone/tablet/desktop and 150% text captures; inspected narrow phone/large-text identity and icon. No launcher install, adaptive-mask/theme or 200%/TalkBack device claim. |
| E05 | `figure_animation/v2/build_report.json`, `validation_report.json`, rig source and tests | Existing mesh/pose figures corroborated by source and passing tests. Prior web checks and device performance claims are not rerun here. Sampled preview frames are under `/tmp/izvoya-audit/`. |
| E06 | SHA-256 comparison of every pre-existing file under `assets/` | **409 files checked; 0 changed.** New identity assets are additional. Original model, images, restoration files and pose data are preserved. Packaged ONNX asset confirmed. |
| E07 | Workspace relocation and regenerated path metadata | **Passed:** moved to `/Users/memre/Desktop/izvoya`, regenerated packages with `flutter pub get --offline`, reran analyzer (no issues) and release APK build (passed). No stale old app identity/path references in implementation files. `adb devices -l` returned no connected devices; physical validation remains open. Verified 36 unique copyable prompts, all update endings, 39 unique districts, 46 score rows and mean, and native XML syntax. |

## Phase ledger

Completion is acceptance-based. A later phase may remain partially complete while independent phases progress; list the unmet gate instead of treating a blocked external step as a pass.

| Phase | Status | Latest evidence / next action |
| --- | --- | --- |
| P00 — Audit, identity and path migration | Complete (local scope) | E01–E07; device/human/release gates remain with their later phases. |
| P01 — Scalable local domain and repository foundation | Not started | Next: implement after dependencies in PHASES.md. |
| P02 — Art direction and distinctive interaction grammar | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P03 — Android shell and first discovery | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P04 — Editorial schema, provenance and city research registry | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P05 — Artwork viewer with a clear primary experience | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P06 — Repeatable 2.5D and authored motion production | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P07 — True 3D Android renderer and first spatial exhibit | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P08 — Downloadable packs and resilient offline use | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P09 — Chora as the flagship collectible chapter | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P10 — Byzantine imperial core beyond Chora | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P11 — Byzantine neighborhoods, ruins and outer connections | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P12 — Atlas, search and geographic discovery | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P13 — Short routes and practical visit planning | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P14 — Mosque architecture and craft flagship chapter | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P15 — Mosques across both shores and architectural periods | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P16 — Museums, objects and collection-level storytelling | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P17 — Museums beyond the obvious and cross-city chapters | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P18 — Complete the 39-district discovery footprint | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P19 — The personal cabinet and a collectible experience library | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P20 — Narrated chapters and silent equivalents | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P21 — Honest Chora recognition and camera reliability | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P22 — Explicitly scoped recognition beyond Chora | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P23 — Shareable discoveries and reliable return paths | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P24 — Reasons to return without pressure | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P25 — Complete Turkish and English editorial delivery | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P26 — Accessibility and Android layout acceptance | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P27 — Lifecycle, permissions, privacy and durable personal data | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P28 — Measured performance, installation size and thermal stability | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P29 — Editorial operations and recoverable content updates | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P30 — Desirability study and distinctiveness review | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P31 — Consent-based measurement and acquisition experiments | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P32 — Automated Android quality and reproducible builds | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P33 — Field trials and release-candidate stability | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P34 — Sustainable release offer, store assets and support | Not started | Use its copyable prompt and dependencies in PHASES.md. |
| P35 — Signed Android candidate, rollback and ship decision | Not started | Use its copyable prompt and dependencies in PHASES.md. |

## Change record

| Date / phase | Visible result | Score movement and evidence | Remaining work / next |
| --- | --- | --- | --- |
| 2026-09-26 / P00 | İzvoya identity, logo, package/native/theme paths; two-file citywide plan and baseline. | D02 25%→75% from implemented identity + E02–E04. Other dimensions established from audited current code; writing the plan adds no feature credit. | Next: P01; relocation/build verified by E07, external O01–O09 documented. No citywide features, true 3D engine or new content claimed. |

## Update protocol after every phase

1. Record phase status: Not started / In progress / Blocked at named gate / Complete. Include build/date and a short visible-result sentence.
2. Update only affected dimension rows, recording old→new scores and actual acceptance evidence. Recompute the arithmetic mean across all active rows. Keep unverified/device/human outcomes explicit; scores need not rise every phase.
3. Link concrete code, screenshots, metrics or test output; give command/result and relevant limitations. Report actual catalogue/district/experience/route counts against PHASES.md minimums as those registries become available.
4. Add one concise change-record row with remaining work and next executable phase. Fix stale evidence when implementation or scope changes; do not accumulate repeated prose.
5. Update **PHASES.md**, including decisions/dependencies and **Open issues**: what requires outside intervention, owner, affected acceptance gate, workaround and resolution. Review both files even when there are no new issues. Keep all further planning/progress Markdown in these two files.

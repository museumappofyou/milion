# Chora front page and visual theme

The app opens on a new front page with an architectural wordmark, a fresco-led
hero, direct access to Anastasis and Last Judgment, reference photographs,
collection browsing and the scanner. Phones use a four-item bottom navigation;
desktop windows use a top navigation bar. The home page and catalog work without
starting the camera or loading the recognition model; inference initializes when
Scan is selected.

The shared theme uses warm ivory, forest green and muted gold, with Cormorant
Garamond display typography and DM Sans for controls and reading. Both fonts are
bundled for offline use, including their SIL Open Font licenses and in-app credits:
[display font source](https://github.com/google/fonts/tree/main/ofl/cormorantgaramond),
[body font source](https://github.com/google/fonts/tree/main/ofl/dmsans).

The collection adds room filters, an Interactive filter, search clearing, helpful
empty results and fresco thumbnails. On web, scene information opens in a labelled,
keyboard-accessible dialog. Native devices retain the bottom sheet. Both preserve
notes and the route into the interactive explorers.

The palette also carries through the scene explorer, restoration studies,
scanner and reference pages. Existing originals, 4K restoration files, animation
rigs, zoom, comparisons, earlier studies and Classic v5 remain available.

## Preview

- [Desktop front page](previews/home_1440x1000.png)
- [Phone front page](previews/home_390x844.png)
- [Phone collection](previews/collection_390x844.png)
- [Scene cards](previews/scenes_1440x1000.png)
- [Larger system text](previews/home_large_text.png)

These are actual Flutter renders. Captures cover 360×800, 390×844, 768×1024 and
1440×1000, plus 150% text scaling. The new page uses existing artwork; the hero
is labelled as a restored interpretation.

## Main files

- `lib/screens/frontier_page.dart`: the new front page.
- `lib/theme/chora_theme.dart`: colors, typography, components and wordmark.
- `lib/screens/home_screen.dart`: adaptive navigation and lazy scanner loading.
- `lib/screens/scenes_tab.dart`: collection filters, cards and scene dialogs.
- `lib/services/classifier.dart`: separates catalog loading from inference setup.
- `web/chora-mark.svg`: vector favicon using the new identity.

## Verification

The full run passed 37 application tests and two visual capture tests. Analysis
reports no issues. The later scene-dialog change passed both relevant test files
(6 tests). Live Chrome checks cover home, collection, Interactive filtering,
scene details, restored animation and navigation at desktop and 360-pixel phone
width. No console errors or warnings occurred in the final review.

```sh
flutter analyze --no-pub
flutter test --no-pub test tool/frontier_screenshot_test.dart
flutter build web --no-pub
flutter build apk --release --no-pub
```

Build and asset verification is recorded in [validation.json](validation.json).
